'use client'

import Link from 'next/link'
import { ShieldCheck, Check, Plus } from 'lucide-react'
import type { ParticipantSummary } from '@/lib/catalog-data'
import { ROLE_LABELS, FACTOR_LABELS, ANCHOR_ROLE_CODES } from '@/lib/catalog-data'
import { TierPill, ProvisionalPill } from '@/components/catalog/tier-pill'

interface ParticipantCardProps {
  participant: ParticipantSummary
  compareSelected?: boolean
  compareDisabled?: boolean
  onCompareToggle?: (id: string) => void
}

export function ParticipantCard({
  participant: p,
  compareSelected = false,
  compareDisabled = false,
  onCompareToggle,
}: ParticipantCardProps) {
  const isProvisional = p.status === 'PROVISIONAL'
  const isAnchorRole  = ANCHOR_ROLE_CODES.includes(p.role_code)

  const dominantLabel =
    !isProvisional && p.dominant_factor
      ? FACTOR_LABELS[p.dominant_factor]
      : null

  function handleCompareClick(e: React.MouseEvent) {
    e.preventDefault()
    e.stopPropagation()
    onCompareToggle?.(p.id)
  }

  return (
    <div className="group relative">
      <Link
        href={`/p/${p.id}`}
        className="block rounded-[16px] bg-card p-5 transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        style={{
          boxShadow:  compareSelected
            ? '0 0 0 2px #533afd, 0 5px 14px 0 rgba(83,58,253,.15)'
            : '0 5px 14px 0 rgba(0,55,112,.08), 0 2px 8px 0 rgba(0,59,137,.05)',
          border:     compareSelected
            ? '1px solid #533afd'
            : '1px solid rgba(212,222,233,.6)',
          transform:  'translateY(0px)',
        }}
        onMouseEnter={(e) => {
          const el = e.currentTarget as HTMLElement
          if (!compareSelected) {
            el.style.boxShadow = '0 6px 22px 0 rgba(0,55,112,.10), 0 4px 8px 0 rgba(0,59,137,.02)'
          }
          el.style.transform = 'translateY(-2px)'
        }}
        onMouseLeave={(e) => {
          const el = e.currentTarget as HTMLElement
          el.style.boxShadow = compareSelected
            ? '0 0 0 2px #533afd, 0 5px 14px 0 rgba(83,58,253,.15)'
            : '0 5px 14px 0 rgba(0,55,112,.08), 0 2px 8px 0 rgba(0,59,137,.05)'
          el.style.transform = 'translateY(0px)'
        }}
      >
        {/* Top row: name + role */}
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 flex-1">
            <p
              className="truncate text-sm font-semibold leading-snug"
              style={{ color: '#061b31', letterSpacing: '-0.01em' }}
            >
              {p.display_name}
            </p>
            <p className="mt-0.5 text-xs" style={{ color: '#64748d' }}>
              {ROLE_LABELS[p.role_code]}
            </p>
          </div>

          {/* Verified-legal badge */}
          {p.verified_legal && (
            <span
              className="mt-0.5 shrink-0 flex items-center gap-1 rounded-full px-1.5 py-px text-[11px] font-medium"
              style={{
                background: 'rgba(0,178,97,.10)',
                color:      '#00732e',
                border:     '1px solid rgba(0,178,97,.28)',
              }}
              title="Verified Legal"
            >
              <ShieldCheck className="h-3 w-3" strokeWidth={2.5} />
              <span>Legal</span>
            </span>
          )}
        </div>

        {/* Trust badge row */}
        <div className="mt-3 flex items-center gap-2">
          {isProvisional ? (
            <ProvisionalPill />
          ) : (
            <>
              <span
                className="tabular-nums text-2xl font-bold leading-none"
                style={{
                  color: p.tier === 'Watch' ? '#b02010' : '#061b31',
                  letterSpacing: '-0.03em',
                }}
              >
                {p.score?.toFixed(1)}
              </span>
              <TierPill tier={p.tier} />
            </>
          )}
        </div>

        {/* Dominant factor */}
        <div className="mt-2.5">
          {isProvisional ? (
            <p className="text-xs" style={{ color: '#5b78a8' }}>
              накопление данных
            </p>
          ) : (
            <p className="text-xs" style={{ color: '#50617a' }}>
              {p.is_balanced || !dominantLabel
                ? 'Сбалансирован'
                : `Доминирующий фактор: ${dominantLabel}`}
            </p>
          )}
        </div>

        {/* Non-anchor MVP badge */}
        {!isAnchorRole && (
          <div className="mt-2">
            <span
              className="inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium"
              style={{
                background: 'rgba(148,164,186,.10)',
                color:      '#64748d',
                border:     '1px solid rgba(148,164,186,.28)',
              }}
              title="Полный Trust Score для этой роли появится в следующих фазах"
            >
              вне MVP-скоупа · provisional
            </span>
          </div>
        )}

        {/* Meta row */}
        <div
          className="mt-3 flex items-center gap-1.5 border-t pt-3 text-[11px]"
          style={{ borderColor: 'rgba(212,222,233,.6)', color: '#7d8ba4' }}
        >
          <span>{p.tests_count} независимых тестов</span>
          <span style={{ color: '#bac8da' }}>·</span>
          <span>обновлено {p.updated_days_ago}д назад</span>
          <span className="ml-auto truncate" style={{ color: '#bac8da' }}>
            {p.domain}
          </span>
        </div>
      </Link>

      {/* Compare toggle button — floats above the link */}
      {onCompareToggle && (
        <button
          onClick={handleCompareClick}
          disabled={compareDisabled && !compareSelected}
          aria-pressed={compareSelected}
          aria-label={compareSelected ? 'Убрать из сравнения' : 'Добавить в сравнение'}
          title={
            compareDisabled && !compareSelected
              ? 'Максимум 5 участников'
              : compareSelected
              ? 'Убрать из сравнения'
              : 'В сравнение'
          }
          className="absolute right-3 top-3 flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium transition-all"
          style={{
            background: compareSelected ? '#533afd' : 'rgba(83,58,253,.08)',
            color:      compareSelected ? '#fff' : '#533afd',
            border:     `1px solid ${compareSelected ? '#533afd' : 'rgba(83,58,253,.25)'}`,
            opacity:    compareDisabled && !compareSelected ? 0.4 : 1,
            cursor:     compareDisabled && !compareSelected ? 'not-allowed' : 'pointer',
          }}
        >
          {compareSelected ? (
            <>
              <Check size={11} strokeWidth={2.5} />
              Выбран
            </>
          ) : (
            <>
              <Plus size={11} strokeWidth={2.5} />
              В сравнение
            </>
          )}
        </button>
      )}
    </div>
  )
}
