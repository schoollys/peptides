'use client'

import { cn } from '@/lib/utils'
import type { ParticipantProfile } from '@/lib/profile-data'

interface TabFactorsProps {
  profile: ParticipantProfile
}

// Maps a 0–100 factor value to an indigo fill width
function valueToWidth(v: number) {
  return `${Math.min(100, Math.max(0, v))}%`
}

// Colour band for progress bar based on value
function progressColor(value: number): string {
  if (value >= 85) return '#533afd'   // brand-600 indigo
  if (value >= 65) return '#7f7dfc'   // brand-400
  if (value >= 45) return '#c9a227'   // gold-tone
  return '#d8351e'                     // error/watch
}

export function TabFactors({ profile }: TabFactorsProps) {
  const { factors, is_balanced, dominant_factor } = profile

  if (!factors || factors.length === 0) {
    return (
      <div className="py-12 text-center text-sm text-muted-foreground">
        Данные по факторам отсутствуют
      </div>
    )
  }

  // Sort: dominant first, then by contribution descending
  const sorted = [...factors].sort((a, b) => {
    if (a.code === dominant_factor) return -1
    if (b.code === dominant_factor) return 1
    return b.contribution - a.contribution
  })

  return (
    <div className="space-y-4">
      {/* Summary row */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        {is_balanced ? (
          <span className="rounded-full bg-accent px-2.5 py-0.5 text-xs font-medium text-accent-foreground">
            Сбалансированный профиль — нет доминирующего фактора
          </span>
        ) : dominant_factor ? (
          <span className="rounded-full bg-accent px-2.5 py-0.5 text-xs font-medium text-accent-foreground">
            Доминирующий фактор: <strong>{dominant_factor}</strong>
          </span>
        ) : null}
      </div>

      {/* Factor cards grid */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {sorted.map((f) => {
          const isDominant = f.code === dominant_factor
          const barColor = progressColor(f.value)

          return (
            <div
              key={f.code}
              className={cn(
                'rounded-xl border bg-white p-4 shadow-stripe-xs transition-shadow hover:shadow-stripe-sm',
                isDominant && 'border-brand-200 ring-1 ring-brand-200'
              )}
              style={isDominant ? { borderColor: 'rgba(127,125,252,.35)' } : undefined}
            >
              {/* Header row */}
              <div className="mb-3 flex items-start justify-between gap-2">
                <div>
                  {/* Factor code badge */}
                  <span
                    className={cn(
                      'inline-block rounded-md px-1.5 py-px font-mono text-xs font-semibold leading-5',
                      isDominant
                        ? 'bg-accent text-accent-foreground'
                        : 'bg-secondary text-secondary-foreground'
                    )}
                  >
                    {f.code}
                  </span>
                  <p className="mt-0.5 text-xs leading-tight text-muted-foreground">
                    {f.label}
                  </p>
                </div>
                {/* Contribution */}
                <div className="text-right">
                  <span className="tabular-nums font-mono text-lg font-semibold leading-none text-foreground">
                    {f.contribution.toFixed(1)}
                  </span>
                  <p className="text-[10px] text-muted-foreground">вклад</p>
                </div>
              </div>

              {/* Progress bar */}
              <div className="mb-3">
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-xs" style={{ color: '#50617a' }}>Значение</span>
                  <span className="tabular-nums font-mono text-xs font-semibold text-foreground">
                    {f.value.toFixed(1)}
                  </span>
                </div>
                <div
                  className="h-1.5 w-full overflow-hidden rounded-full"
                  style={{ background: 'rgba(83,58,253,.10)' }}
                  role="progressbar"
                  aria-valuenow={f.value}
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-label={`${f.label}: ${f.value.toFixed(1)} из 100`}
                >
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: valueToWidth(f.value), background: barColor }}
                  />
                </div>
              </div>

              {/* Meta row */}
              <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                <span>
                  V<sub>i</sub>{' '}
                  <span className="tabular-nums font-mono font-medium text-foreground/70">
                    {f.v_i.toFixed(2)}
                  </span>
                </span>
                <div className="flex items-center gap-1.5">
                  <span className="text-muted-foreground/70">
                    d<sub>i</sub>{' '}
                    <span className="tabular-nums font-mono">{f.freshness_di}д</span>
                  </span>
                  {/* di_class freshness badge */}
                  <span
                    className="rounded px-1 py-px font-mono text-[10px] font-semibold leading-4"
                    style={{
                      background: f.di_class === 'A' ? 'rgba(0,178,97,.12)'
                        : f.di_class === 'B' ? 'rgba(83,58,253,.10)'
                        : f.di_class === 'C' ? 'rgba(201,162,39,.12)'
                        : 'rgba(216,53,30,.10)',
                      color: f.di_class === 'A' ? '#006d3d'
                        : f.di_class === 'B' ? '#3a28c0'
                        : f.di_class === 'C' ? '#8a6800'
                        : '#b02010',
                    }}
                  >
                    {f.di_class}
                  </span>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Formula footnote */}
      <p className="pt-1 text-[11px] text-muted-foreground">
        Вклад = value × V<sub>i</sub>. V<sub>i</sub> — множитель верификации (0–1). d<sub>i</sub> — дней с последнего измерения.
      </p>
    </div>
  )
}
