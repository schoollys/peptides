'use client'

import Link from 'next/link'
import { AlertTriangle, Info, XCircle, CheckCircle2, Activity } from 'lucide-react'
import type { ParticipantProfile, Flag, FlagSeverity } from '@/lib/profile-data'
import { FACTOR_LABELS } from '@/lib/catalog-data'
import { TierPill, ProvisionalPill } from '@/components/catalog/tier-pill'
import { INCIDENTS_BY_PARTICIPANT } from '@/lib/incidents-data'
import { cn } from '@/lib/utils'

// ─── Flag severity config ────────────────────────────────────────────────────
const SEVERITY_CONFIG: Record<
  FlagSeverity,
  { icon: React.ElementType; bg: string; border: string; text: string; badge: string; badgeText: string }
> = {
  INFO: {
    icon: Info,
    bg: 'rgba(83,58,253,.05)',
    border: 'rgba(83,58,253,.18)',
    text: '#273951',
    badge: 'rgba(83,58,253,.10)',
    badgeText: '#3a28c0',
  },
  WARNING: {
    icon: AlertTriangle,
    bg: 'rgba(201,162,39,.07)',
    border: 'rgba(201,162,39,.28)',
    text: '#273951',
    badge: 'rgba(201,162,39,.14)',
    badgeText: '#8a6800',
  },
  CRITICAL: {
    icon: XCircle,
    bg: 'rgba(216,53,30,.06)',
    border: 'rgba(216,53,30,.22)',
    text: '#273951',
    badge: 'rgba(216,53,30,.10)',
    badgeText: '#b02010',
  },
}

const STATUS_LABELS: Record<string, string> = {
  OPEN: 'Открыт',
  RESOLVED: 'Устранён',
  MONITORING: 'Мониторинг',
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('ru-RU', {
    day: '2-digit', month: 'short', year: 'numeric',
  })
}

interface FlagItemProps {
  flag: Flag
  participantId: string
}

function FlagItem({ flag, participantId }: FlagItemProps) {
  const cfg = SEVERITY_CONFIG[flag.severity]
  const Icon = cfg.icon

  // Check if there's a matching incident in the log for this flag
  const incidentId = `inc-${participantId}-${flag.id}`
  const hasIncident = (INCIDENTS_BY_PARTICIPANT[participantId] ?? [])
    .some(inc => inc.id === incidentId)

  return (
    <div
      className="flex gap-3 rounded-xl p-4"
      style={{ background: cfg.bg, border: `1px solid ${cfg.border}` }}
    >
      <Icon
        size={16}
        className="mt-0.5 flex-shrink-0"
        style={{ color: cfg.badgeText }}
      />
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          {/* Severity */}
          <span
            className="rounded-full px-2 py-px text-[11px] font-semibold"
            style={{ background: cfg.badge, color: cfg.badgeText }}
          >
            {flag.severity}
          </span>
          {/* Type */}
          <span className="font-mono text-xs text-muted-foreground">
            {flag.type}
          </span>
          {/* Status */}
          <span
            className="ml-auto rounded-full px-2 py-px text-[11px]"
            style={{
              background: flag.status === 'RESOLVED'
                ? 'rgba(0,178,97,.10)'
                : 'rgba(100,116,141,.10)',
              color: flag.status === 'RESOLVED' ? '#006d3d' : '#505a61',
            }}
          >
            {STATUS_LABELS[flag.status] ?? flag.status}
          </span>
        </div>
        <p className="mt-1.5 text-sm" style={{ color: cfg.text }}>
          {flag.message}
        </p>
        <div className="mt-1 flex flex-wrap items-center gap-3">
          <p className="text-[11px] text-muted-foreground">
            {formatDate(flag.raised_at)}
          </p>
          {hasIncident && (
            <Link
              href={`/incidents#inc-${incidentId}`}
              className="text-[11px] font-medium hover:underline"
              style={{ color: '#533afd' }}
            >
              Открыть в логе инцидентов →
            </Link>
          )}
          {flag.status !== 'RESOLVED' && (
            <Link
              href={`/appeals/new?subject=${participantId}&flag=${flag.id}`}
              className="text-[11px] font-medium hover:underline"
              style={{ color: '#b02010' }}
            >
              Оспорить →
            </Link>
          )}
        </div>
      </div>
    </div>
  )
}

interface TabOverviewProps {
  profile: ParticipantProfile
}

export function TabOverview({ profile }: TabOverviewProps) {
  const isProvisional = profile.status === 'PROVISIONAL'
  const topFactors = [...profile.factors]
    .sort((a, b) => b.contribution - a.contribution)
    .slice(0, 3)

  return (
    <div className="space-y-6">

      {/* Provisional notice */}
      {isProvisional && profile.provisional_reason && (
        <div
          className="rounded-xl p-4"
          style={{
            background: 'rgba(201,162,39,.07)',
            border: '1px solid rgba(201,162,39,.28)',
          }}
        >
          <div className="flex gap-3">
            <AlertTriangle size={16} className="mt-0.5 flex-shrink-0 text-amber-600" />
            <div>
              <p className="mb-1 text-sm font-semibold text-foreground">
                Provisional — Trust Score не рассчитан
              </p>
              <p className="text-sm text-muted-foreground">
                {profile.provisional_reason}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Two-column summary grid */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {/* Trust Score */}
        <div className="rounded-xl border border-border bg-white p-4 shadow-stripe-xs">
          <p className="mb-1 text-xs text-muted-foreground">Trust Score</p>
          {isProvisional ? (
            <div className="flex items-center gap-2">
              <span className="tabular-nums font-mono text-2xl font-semibold text-muted-foreground">—</span>
              <ProvisionalPill />
            </div>
          ) : (
            <div className="flex items-baseline gap-1.5">
              <span className="tabular-nums font-mono text-2xl font-semibold text-foreground">
                {profile.score?.toFixed(1)}
              </span>
              <span className="text-xs text-muted-foreground">/ 100</span>
            </div>
          )}
        </div>

        {/* Tier */}
        <div className="rounded-xl border border-border bg-white p-4 shadow-stripe-xs">
          <p className="mb-1 text-xs text-muted-foreground">Тир</p>
          <TierPill tier={profile.tier} size="md" />
          {profile.trust_ceiling < 100 && (
            <p className="mt-1 text-xs text-muted-foreground">
              Потолок: {profile.trust_ceiling}
            </p>
          )}
        </div>

        {/* Tests count */}
        <div className="rounded-xl border border-border bg-white p-4 shadow-stripe-xs">
          <p className="mb-1 text-xs text-muted-foreground">Независимых тестов</p>
          <span className="tabular-nums font-mono text-2xl font-semibold text-foreground">
            {profile.tests_count}
          </span>
        </div>

        {/* KYB level */}
        <div className="rounded-xl border border-border bg-white p-4 shadow-stripe-xs">
          <p className="mb-1 text-xs text-muted-foreground">Уровень KYB</p>
          <span className="tabular-nums font-mono text-2xl font-semibold text-foreground">
            {profile.kyb_level}
          </span>
          <p className="mt-0.5 text-[11px] text-muted-foreground">
            {profile.kyb_level === 'L3' ? 'Полная верификация'
              : profile.kyb_level === 'L2' ? 'Расширенная'
              : profile.kyb_level === 'L1' ? 'Базовая'
              : 'Не верифицирован'}
          </p>
        </div>
      </div>

      {/* Top factors snapshot (if any) */}
      {topFactors.length > 0 && (
        <div className="rounded-xl border border-border bg-white shadow-stripe-xs">
          <div className="border-b border-border px-4 py-3">
            <h3 className="text-sm font-semibold text-foreground">
              Ведущие факторы
            </h3>
            <p className="text-xs text-muted-foreground">
              Топ-3 по вкладу в Trust Score
            </p>
          </div>
          <div className="divide-y divide-border">
            {topFactors.map((f) => (
              <div key={f.code} className="flex items-center gap-4 px-4 py-3">
                <span
                  className="inline-block rounded-md px-1.5 py-px font-mono text-xs font-semibold"
                  style={{ background: 'rgba(83,58,253,.08)', color: '#3a28c0' }}
                >
                  {f.code}
                </span>
                <span className="min-w-0 flex-1 truncate text-xs text-muted-foreground">
                  {f.label}
                </span>
                {/* Mini progress */}
                <div className="flex w-24 items-center gap-2">
                  <div
                    className="h-1.5 flex-1 overflow-hidden rounded-full"
                    style={{ background: 'rgba(83,58,253,.10)' }}
                  >
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${f.value}%`, background: '#533afd' }}
                    />
                  </div>
                  <span className="tabular-nums font-mono text-xs font-semibold text-foreground">
                    {f.value}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Flags block ─────────────────────────────────────────── */}
      <div className="rounded-xl border border-border bg-white shadow-stripe-xs">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div>
            <h3 className="text-sm font-semibold text-foreground">Флаги</h3>
            <p className="text-xs text-muted-foreground">
              Активные уведомления и предупреждения
            </p>
          </div>
          {profile.flags.length > 0 && (
            <span
              className="tabular-nums rounded-full px-2 py-0.5 text-xs font-semibold"
              style={{ background: 'rgba(216,53,30,.10)', color: '#b02010' }}
            >
              {profile.flags.length}
            </span>
          )}
        </div>

        <div className="p-4">
          {profile.flags.length === 0 ? (
            <div className="flex items-center gap-2.5 text-sm text-muted-foreground">
              <CheckCircle2 size={16} className="flex-shrink-0" style={{ color: '#00b261' }} />
              <span>Нет активных флагов</span>
            </div>
          ) : (
            <div className="space-y-2.5">
              {profile.flags.map((flag) => (
                <FlagItem key={flag.id} flag={flag} participantId={profile.id} />
              ))}
            </div>
          )}
        </div>

        {/* Micro-disclaimer on flags block */}
        {/* TODO: на ревью юриста */}
        <div
          className="flex items-start gap-2 border-t border-border px-4 py-2.5"
          style={{ background: 'rgba(248,250,253,.8)' }}
        >
          <svg className="mt-0.5 shrink-0" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#95a4ba" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
          <p className="text-[11px] leading-relaxed" style={{ color: '#95a4ba' }}>
            Информационная оценка, не обвинение.{' '}
            Флаги отражают задокументированные данные, а не юридические выводы.{' '}
            <a href="/legal/disclaimer" className="underline hover:no-underline" style={{ color: '#7d8ba4' }}>
              Отказ от ответственности
            </a>
            {' · '}
            <a href="/appeals/new" className="underline hover:no-underline" style={{ color: '#7d8ba4' }}>
              Оспорить
            </a>
          </p>
        </div>
      </div>
    </div>
  )
}
