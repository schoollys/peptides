import { CheckCircle2, Clock, ExternalLink, FileText, Shield } from 'lucide-react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import type { ClaimResponse } from '@/lib/claim-data'

interface StepProvisionalProps {
  response: ClaimResponse
}

export function StepProvisional({ response }: StepProvisionalProps) {
  const estimatedDate = response.estimated_provisional_at
    ? new Date(response.estimated_provisional_at).toLocaleDateString('ru-RU', {
        day:   'numeric',
        month: 'long',
        year:  'numeric',
      })
    : null

  return (
    <div className="space-y-6">
      {/* Success banner */}
      <div
        role="status"
        aria-live="polite"
        className="rounded-xl border px-5 py-5 space-y-3"
        style={{ borderColor: '#00b26133', backgroundColor: '#00b2610d' }}
      >
        <div className="flex items-start gap-3">
          <CheckCircle2 className="mt-0.5 size-5 shrink-0" style={{ color: '#00b261' }} />
          <div className="space-y-1">
            <p className="text-sm font-semibold" style={{ color: '#00b261' }}>
              Заявление принято — 202 Accepted
            </p>
            <p className="text-sm text-[#3c4f69] leading-relaxed">
              Статус:{' '}
              <span className="font-semibold">pending_verification</span>
              {' → '}
              <span className="font-semibold">provisional</span> после подтверждения
            </p>
          </div>
        </div>

        {/* Claim meta */}
        <div className="mt-1 grid grid-cols-1 gap-1.5 border-t pt-3" style={{ borderColor: '#00b26122' }}>
          <MetaRow label="claim_id"         value={response.claim_id}        mono />
          <MetaRow label="Контакт"          value={response.contact} />
          <MetaRow label="Уровень"          value={response.requested_level} />
          <MetaRow label="Отправлено"       value={new Date(response.submitted_at).toLocaleString('ru-RU')} />
          {estimatedDate && (
            <MetaRow label="Ожидаемый provisional" value={estimatedDate} />
          )}
        </div>
      </div>

      {/* Steps ahead */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-[#061b31]">Что дальше</h3>
        <ol className="space-y-3">
          <TimelineItem
            icon={<Clock className="size-4" style={{ color: '#533afd' }} />}
            title="Ручная верификация (1–2 рабочих дня)"
            description={`Команда PeptideTrust проверит заявление и свяжется с вами по адресу ${response.contact}.`}
          />
          <TimelineItem
            icon={<Shield className="size-4" style={{ color: '#533afd' }} />}
            title="Статус → provisional"
            description="Профиль получит временный Trust Score и пилюлю «Provisional». Данные накапливаются — ограничений на факторы нет."
          />
          <TimelineItem
            icon={<FileText className="size-4" style={{ color: '#533afd' }} />}
            title="Финальная активация"
            description="После полного прохождения KYB/KYC статус сменится на active. Trust Ceiling определяется уровнем верификации."
          />
        </ol>
      </div>

      {/* Explainer note */}
      <div
        className="rounded-xl border px-4 py-3.5 space-y-1.5"
        style={{ borderColor: '#635bff33', backgroundColor: '#e8e9ff55' }}
      >
        <p className="text-xs font-semibold" style={{ color: '#533afd' }}>
          PoP L0 и Trust Ceiling
        </p>
        <p className="text-xs text-[#3c4f69] leading-relaxed">
          PoP L0 — минимальный уровень Proof-of-Person, достаточный для потребительских участников.
          Fallback по юрисдикции автоматически применяет Trust Ceiling из реестра FS-ISAC:
          если регуляторный режим страны не позволяет верификацию L3, максимальный Score
          ограничивается на уровне Gold (80).
        </p>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Link href={`/p/${response.participant_id}`} className="flex-1">
          <Button
            variant="default"
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
          >
            Перейти к профилю
          </Button>
        </Link>
        <Link href="/catalog" className="flex-1">
          <Button variant="outline" className="w-full">
            Вернуться в каталог
          </Button>
        </Link>
      </div>

      {/* Request ID for support */}
      <div className="flex items-center gap-2 rounded-lg border border-dashed border-border px-3 py-2.5">
        <ExternalLink className="size-3.5 shrink-0 text-muted-foreground" />
        <p className="text-xs text-muted-foreground">
          Для обращения в поддержку:&nbsp;
          <code className="font-mono text-[11px] text-[#3c4f69]">{response.request_id}</code>
        </p>
      </div>
    </div>
  )
}

function MetaRow({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-4">
      <span className="text-xs text-muted-foreground shrink-0">{label}</span>
      <span
        className={`text-xs text-right truncate max-w-[60%] ${mono ? 'font-mono text-[#3c4f69]' : 'font-medium text-[#273951]'}`}
      >
        {value}
      </span>
    </div>
  )
}

function TimelineItem({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode
  title: string
  description: string
}) {
  return (
    <li className="flex gap-3">
      <div
        className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full"
        style={{ backgroundColor: '#e8e9ff' }}
      >
        {icon}
      </div>
      <div className="space-y-0.5 pt-0.5">
        <p className="text-sm font-semibold text-[#061b31]">{title}</p>
        <p className="text-xs text-muted-foreground leading-relaxed">{description}</p>
      </div>
    </li>
  )
}
