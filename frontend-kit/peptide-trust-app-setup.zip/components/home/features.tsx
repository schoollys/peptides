import { FileCheck, Scale, ShieldAlert, BarChart3, Layers, Globe } from 'lucide-react'

const features = [
  {
    icon: FileCheck,
    title: 'Верификация документов',
    desc: 'Сертификаты GMP, COA и лицензии проверяются по реестрам надзорных органов. Хеш каждого документа публичен.',
  },
  {
    icon: Scale,
    title: 'Нейтральная позиция',
    desc: 'PeptideTrust не принимает рекламные деньги и не влияет на Score через коммерческие отношения.',
  },
  {
    icon: ShieldAlert,
    title: 'Лог инцидентов',
    desc: 'Открытый реестр нарушений с временными метками. Ни один инцидент не удаляется без публичного объяснения.',
  },
  {
    icon: BarChart3,
    title: 'Trust Score 0–100 с доминирующим фактором',
    desc: 'Алгоритм учитывает 9 независимых факторов (качество, логистика, прозрачность…). Score всегда показывается с доминирующим фактором или как «сбалансирован».',
  },
  {
    icon: Layers,
    title: 'Сравнение компаний',
    desc: 'Сравнивайте участников в рамках одного сегмента по ключевым факторам.',
  },
  {
    icon: Globe,
    title: 'API для интеграций',
    desc: 'REST API с webhook-уведомлениями об изменении Trust Score для встраивания в вашу систему.',
  },
]

export function Features() {
  return (
    <section className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-16">
      <div className="mb-10 text-center">
        <h2
          className="text-2xl font-light"
          style={{ color: '#061b31', letterSpacing: '-0.01em' }}
        >
          Почему реестр, а не маркетплейс
        </h2>
        <p className="mt-2 text-sm" style={{ color: '#64748d' }}>
          Независимость обеспечивается структурой данных и открытым журналом аудита.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((f) => {
          const Icon = f.icon
          return (
            <div
              key={f.title}
              className="rounded-2xl bg-card p-6 border border-border flex flex-col gap-3 shadow-stripe-xs hover:shadow-stripe-sm transition-shadow duration-200"
            >
              <div
                className="flex h-9 w-9 items-center justify-center rounded-lg"
                style={{ background: '#e8e9ff' }}
              >
                <Icon className="h-4 w-4" style={{ color: '#533afd' }} strokeWidth={1.75} />
              </div>
              <div>
                <h3
                  className="text-sm font-medium"
                  style={{ color: '#061b31', letterSpacing: '-0.005em' }}
                >
                  {f.title}
                </h3>
                <p className="mt-1 text-sm leading-relaxed" style={{ color: '#64748d' }}>
                  {f.desc}
                </p>
              </div>
            </div>
          )
        })}
      </div>
    </section>
  )
}
