import Link from 'next/link'
import { ArrowRight, ShieldCheck } from 'lucide-react'

export function SupplierCTA() {
  return (
    <section className="border-y border-border bg-card">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-10">
        <div
          className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 rounded-2xl px-6 py-6"
          style={{
            background: 'linear-gradient(100deg, #f5f5ff 0%, #e8e9ff 100%)',
            border: '1px solid #d6d9fc',
          }}
        >
          {/* Icon + text */}
          <div className="flex items-start gap-4">
            <div
              className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
              style={{ background: '#533afd' }}
            >
              <ShieldCheck className="h-5 w-5 text-white" strokeWidth={2} />
            </div>
            <div>
              <p
                className="text-sm font-medium"
                style={{ color: '#061b31', letterSpacing: '-0.005em' }}
              >
                Вы производитель или поставщик?
              </p>
              <p className="mt-0.5 text-sm leading-relaxed" style={{ color: '#50617a' }}>
                Заявите профиль и получите верифицированный Trust Score — независимую оценку, которой доверяют покупатели.
              </p>
            </div>
          </div>

          {/* CTA — CSS-only hover via group trick */}
          <Link
            href="/claim"
            className="inline-flex shrink-0 items-center gap-1.5 rounded px-4 py-2 text-sm font-medium text-white transition-colors duration-150"
            style={{ background: '#533afd', borderRadius: '4px' }}
          >
            Заявить профиль
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </div>
    </section>
  )
}
