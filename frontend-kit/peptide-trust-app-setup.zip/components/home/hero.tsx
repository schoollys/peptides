'use client'

import Link from 'next/link'
import { Search, ArrowRight } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'

const recentSearches = ['AlphaPep Lab', 'BioSynth RU', 'PrimePeptides']

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-card">
      {/* Gradient mesh backdrop — upper third */}
      <div
        className="absolute inset-0 pointer-events-none"
        aria-hidden="true"
        style={{
          background: `
            radial-gradient(60% 80% at 75% 10%, #ffe5da 0%, rgba(255,229,218,0) 55%),
            radial-gradient(50% 70% at 90% 20%, #ff6118 0%, rgba(255,97,24,0) 50%),
            radial-gradient(55% 75% at 95% 45%, #f44bcc 0%, rgba(244,75,204,0) 55%),
            radial-gradient(60% 80% at 80% 60%, #ea2261 0%, rgba(234,34,97,0) 55%),
            radial-gradient(70% 90% at 60% 30%, #7f7dfc 0%, rgba(127,125,252,0) 60%)
          `,
          filter: 'saturate(1.05)',
          opacity: 0.18,
        }}
      />

      <div className="relative mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-20 md:py-28 text-center flex flex-col items-center gap-8">
        {/* Label pill */}
        <div
          className="inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-medium"
          style={{ borderColor: '#d6d9fc', background: '#f5f5ff', color: '#533afd' }}
        >
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: '#533afd' }} />
          Нейтральный публичный реестр · Не маркетплейс
        </div>

        {/* Headline */}
        <div className="flex flex-col gap-3 max-w-3xl">
          <h1
            className="text-4xl sm:text-5xl md:text-[3.25rem] font-light leading-tight"
            style={{ color: '#061b31', letterSpacing: '-0.03em' }}
          >
            Реестр доверия участников рынка пептидов
          </h1>
          <p className="text-base sm:text-lg leading-relaxed" style={{ color: '#50617a' }}>
            Проверяйте производителей и поставщиков по независимому Trust Score. Данные верифицируются, а не покупаются.
          </p>
        </div>

        {/* Search bar */}
        <div className="w-full max-w-xl">
          <div className="relative flex items-center">
            <Search
              className="pointer-events-none absolute left-4 h-4 w-4"
              style={{ color: '#7d8ba4' }}
            />
            <Input
              placeholder="Введите название компании, ID участника или хеш документа..."
              className="h-11 pl-11 pr-28 text-sm"
              style={{ borderRadius: '8px', borderColor: '#bac8da' }}
            />
            <Button
              className="absolute right-1.5 h-8 text-xs"
              style={{ borderRadius: '6px' }}
            >
              Найти
            </Button>
          </div>
          <div className="mt-2 flex flex-wrap items-center justify-center gap-x-3 gap-y-1">
            <span className="text-xs" style={{ color: '#95a4ba' }}>Например:</span>
            {recentSearches.map((s) => (
              <button
                key={s}
                className="text-xs text-primary hover:text-primary/70 transition-colors duration-150"
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* CTA links */}
        <div className="flex flex-wrap gap-4 items-center justify-center">
          <Link
            href="/catalog"
            className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors duration-150"
          >
            Перейти в каталог
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
          <Link
            href="/trust-model"
            className="inline-flex items-center gap-1.5 text-sm transition-colors duration-150"
            style={{ color: '#64748d' }}
          >
            Как работает Trust Score
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </div>
    </section>
  )
}
