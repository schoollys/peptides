'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Search, Menu, X, ShieldCheck, LogOut } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { useAuth } from '@/lib/auth'

const navItems = [
  { label: 'Каталог',   href: '/catalog' },
  { label: 'Сравнение', href: '/compare' },
]

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const { isLoggedIn, user, logout } = useAuth()

  return (
    <header
      className="sticky top-0 z-50 w-full border-b border-border bg-card"
      style={{ boxShadow: '0 2px 10px 0 rgba(0,55,112,.06), 0 1px 4px 0 rgba(0,59,137,.04)' }}
    >
      <div className="mx-auto flex h-14 max-w-7xl items-center gap-6 px-4 sm:px-6 lg:px-8">
        {/* Wordmark */}
        <Link href="/" className="flex shrink-0 items-center gap-2">
          <span
            className="flex h-7 w-7 items-center justify-center rounded"
            style={{ background: '#533afd' }}
          >
            <ShieldCheck className="h-4 w-4 text-white" strokeWidth={2.5} />
          </span>
          <span
            className="text-sm font-semibold select-none"
            style={{ color: '#061b31', letterSpacing: '-0.01em' }}
          >
            PeptideTrust
          </span>
        </Link>

        {/* Desktop search */}
        <div className="hidden flex-1 max-w-sm md:flex">
          <div className="relative w-full">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5"
              style={{ color: '#7d8ba4' }}
            />
            <Input
              placeholder="Поиск по имени, ID участника, хешу…"
              className="h-8 pl-8 text-sm border-input bg-background focus-visible:ring-ring"
              style={{ borderRadius: '6px' }}
            />
          </div>
        </div>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="px-3 py-1.5 text-sm rounded transition-colors duration-150"
              style={{ color: '#50617a' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = '#533afd'
                e.currentTarget.style.background = '#e8e9ff'
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = '#50617a'
                e.currentTarget.style.background = 'transparent'
              }}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex-1" />

        {/* Desktop CTA — conditional on auth */}
        <div className="hidden md:flex items-center gap-2">
          {isLoggedIn && user ? (
            <>
              {/* Avatar chip */}
              <Link
                href="/dashboard"
                className="inline-flex items-center gap-2 rounded-full py-1 pl-1 pr-3 text-sm font-medium transition-colors hover:bg-[#f0f2f7]"
                style={{ color: '#3c4f69' }}
              >
                <span
                  className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold text-white select-none"
                  style={{ background: '#533afd' }}
                  aria-hidden="true"
                >
                  {user.initials}
                </span>
                Кабинет
              </Link>
              {/* Logout */}
              <button
                onClick={logout}
                className="flex items-center gap-1.5 rounded px-2 py-1.5 text-xs transition-colors hover:bg-[#f0f2f7]"
                style={{ color: '#64748d' }}
                aria-label="Выйти"
              >
                <LogOut size={13} />
                Выйти
              </button>
            </>
          ) : (
            <>
              <Link
                href="/login"
                className="px-3 py-1.5 text-sm transition-colors duration-150"
                style={{ color: '#533afd' }}
                onMouseEnter={(e) => (e.currentTarget.style.color = '#4032c8')}
                onMouseLeave={(e) => (e.currentTarget.style.color = '#533afd')}
              >
                Войти
              </Link>
              <Link
                href="/claim"
                className="inline-flex h-8 items-center justify-center rounded px-3 text-sm font-medium text-white transition-colors duration-150"
                style={{ background: '#533afd', borderRadius: '4px' }}
                onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.background = '#4032c8')}
                onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.background = '#533afd')}
              >
                Заявить профиль
              </Link>
            </>
          )}
        </div>

        {/* Mobile search toggle */}
        <button
          aria-label="Поиск"
          className="md:hidden p-2 rounded"
          style={{ color: '#64748d' }}
          onClick={() => setSearchOpen((v) => !v)}
        >
          <Search className="h-4 w-4" />
        </button>

        {/* Mobile menu toggle */}
        <button
          aria-label={mobileOpen ? 'Закрыть меню' : 'Открыть меню'}
          className="md:hidden p-2 rounded"
          style={{ color: '#64748d' }}
          onClick={() => setMobileOpen((v) => !v)}
        >
          {mobileOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </button>
      </div>

      {/* Mobile search bar */}
      {searchOpen && (
        <div className="border-t border-border px-4 py-3 md:hidden">
          <div className="relative">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5"
              style={{ color: '#7d8ba4' }}
            />
            <Input
              autoFocus
              placeholder="Поиск..."
              className="h-9 pl-8 text-sm"
              style={{ borderRadius: '6px' }}
            />
          </div>
        </div>
      )}

      {/* Mobile nav */}
      {mobileOpen && (
        <nav className="border-t border-border bg-card px-4 pb-4 pt-2 md:hidden">
          <ul className="flex flex-col gap-1">
            {navItems.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className="block rounded px-3 py-2 text-sm transition-colors duration-150"
                  style={{ color: '#50617a' }}
                  onClick={() => setMobileOpen(false)}
                >
                  {item.label}
                </Link>
              </li>
            ))}
            <li className="mt-2 flex gap-2 pt-2 border-t border-border">
              {isLoggedIn && user ? (
                <>
                  <Link
                    href="/dashboard"
                    className="flex flex-1 items-center gap-2 rounded py-2 pl-1 pr-3 text-sm font-medium"
                    style={{ color: '#3c4f69' }}
                    onClick={() => setMobileOpen(false)}
                  >
                    <span
                      className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[11px] font-bold text-white select-none"
                      style={{ background: '#533afd' }}
                    >
                      {user.initials}
                    </span>
                    Кабинет
                  </Link>
                  <button
                    onClick={() => { logout(); setMobileOpen(false) }}
                    className="rounded px-3 py-2 text-sm transition-colors"
                    style={{ color: '#64748d' }}
                  >
                    Выйти
                  </button>
                </>
              ) : (
                <>
                  <Link
                    href="/login"
                    className="flex-1 text-center rounded py-2 text-sm transition-colors duration-150"
                    style={{ color: '#533afd' }}
                    onClick={() => setMobileOpen(false)}
                  >
                    Войти
                  </Link>
                  <Link
                    href="/claim"
                    className="flex-1 text-center rounded py-2 text-sm font-medium text-white transition-colors duration-150"
                    style={{ background: '#533afd', borderRadius: '4px' }}
                    onClick={() => setMobileOpen(false)}
                  >
                    Заявить профиль
                  </Link>
                </>
              )}
            </li>
          </ul>
        </nav>
      )}
    </header>
  )
}
