'use client'

import type { ParticipantProfile } from '@/lib/profile-data'
import type { Tier } from '@/lib/catalog-data'

// ── Tier colour palette (matches tier-pill.tsx exactly) ─────────────────────
const TIER_COLORS: Record<Tier, { bg: string; text: string; dot: string }> = {
  Platinum: { bg: '#dce6f0', text: '#2e4a62', dot: '#8ca0b8' },
  Gold:     { bg: '#faf0cc', text: '#7a5800', dot: '#c9a227' },
  Silver:   { bg: '#e8eaeb', text: '#3d474e', dot: '#9aa0a6' },
  Bronze:   { bg: '#f5e8da', text: '#6b3d10', dot: '#b07a45' },
  Watch:    { bg: '#fce8e5', text: '#8b1a0e', dot: '#d8351e' },
}

// Dark overrides — same hue, inverted lightness
const TIER_COLORS_DARK: Record<Tier, { bg: string; text: string; dot: string }> = {
  Platinum: { bg: '#1c2e3d', text: '#a8c4d8', dot: '#8ca0b8' },
  Gold:     { bg: '#2e2200', text: '#f5c842', dot: '#c9a227' },
  Silver:   { bg: '#1f2428', text: '#b0b8bf', dot: '#9aa0a6' },
  Bronze:   { bg: '#2a1a08', text: '#d4a06a', dot: '#b07a45' },
  Watch:    { bg: '#2e0a06', text: '#f07060', dot: '#d8351e' },
}

interface BadgePreviewProps {
  profile: ParticipantProfile
  theme: 'light' | 'dark'
}

// ── Inline SVG badge (pure SVG, mirrors what the server would sign) ──────────
export function BadgeSvg({ profile, theme }: BadgePreviewProps) {
  const palette   = theme === 'dark' ? TIER_COLORS_DARK : TIER_COLORS
  const tierCfg   = palette[profile.tier]
  const isProvis  = profile.status === 'PROVISIONAL' || profile.score === null

  // Layout constants
  const W         = 260
  const H         = 72
  const RADIUS    = 10
  const PAD_X     = 14
  const PAD_Y     = 12

  const bg        = theme === 'dark' ? '#0f1923' : '#ffffff'
  const border    = theme === 'dark' ? '#1e2f40' : '#e5edf5'
  const textMain  = theme === 'dark' ? '#e8f0f8' : '#061b31'
  const textSub   = theme === 'dark' ? '#6a8aaa' : '#64748d'
  const brandFg   = theme === 'dark' ? '#a09dff' : '#533afd'

  const scoreStr  = isProvis ? '—' : String(profile.score?.toFixed(1) ?? '—')
  const tierLabel = profile.tier

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={W}
      height={H}
      viewBox={`0 0 ${W} ${H}`}
      role="img"
      aria-label={`Trust badge: ${profile.display_name}, Score ${scoreStr}, Tier ${tierLabel}`}
    >
      <defs>
        <clipPath id="clip-badge">
          <rect width={W} height={H} rx={RADIUS} />
        </clipPath>
      </defs>

      {/* Card background */}
      <rect width={W} height={H} rx={RADIUS} fill={bg} />
      <rect width={W} height={H} rx={RADIUS} fill="none" stroke={border} strokeWidth="1" />

      {/* Left accent bar */}
      <rect x="0" y="0" width="4" height={H} rx={RADIUS} clipPath="url(#clip-badge)" fill={tierCfg.dot} />

      {/* Score — large tabular number */}
      <text
        x={PAD_X + 14}
        y={PAD_Y + 22}
        fontFamily="'Inter', -apple-system, sans-serif"
        fontWeight="700"
        fontSize="26"
        fill={textMain}
        letterSpacing="-0.5"
        fontVariantNumeric="tabular-nums"
        textAnchor="middle"
      >
        {scoreStr}
      </text>

      {/* "Trust Score" label under number */}
      <text
        x={PAD_X + 14}
        y={PAD_Y + 34}
        fontFamily="'Inter', -apple-system, sans-serif"
        fontWeight="400"
        fontSize="8.5"
        fill={textSub}
        textAnchor="middle"
        letterSpacing="0.3"
      >
        TRUST SCORE
      </text>

      {/* Divider */}
      <line x1="52" y1="14" x2="52" y2={H - 14} stroke={border} strokeWidth="1" />

      {/* Right side: display_name */}
      <text
        x="62"
        y={PAD_Y + 10}
        fontFamily="'Inter', -apple-system, sans-serif"
        fontWeight="600"
        fontSize="11.5"
        fill={textMain}
        letterSpacing="-0.1"
      >
        {profile.display_name.length > 22
          ? profile.display_name.slice(0, 22) + '…'
          : profile.display_name}
      </text>

      {/* Tier pill background */}
      <rect
        x="62"
        y={PAD_Y + 16}
        width="62"
        height="16"
        rx="8"
        fill={tierCfg.bg}
        stroke={tierCfg.dot}
        strokeWidth="0.75"
        strokeOpacity="0.6"
      />
      {/* Tier dot */}
      <circle cx="75" cy={PAD_Y + 24} r="3.5" fill={tierCfg.dot} />
      {/* Tier label */}
      <text
        x="82"
        y={PAD_Y + 27.5}
        fontFamily="'Inter', -apple-system, sans-serif"
        fontWeight="500"
        fontSize="9.5"
        fill={tierCfg.text}
      >
        {tierLabel}
      </text>

      {/* PeptideTrust verified mark */}
      <text
        x="62"
        y={H - PAD_Y + 2}
        fontFamily="'Inter', -apple-system, sans-serif"
        fontWeight="500"
        fontSize="9"
        fill={brandFg}
        letterSpacing="-0.1"
      >
        PeptideTrust ✓
      </text>
    </svg>
  )
}

// ── Theme segmented control + preview wrapper ────────────────────────────────
interface BadgePreviewCardProps {
  profile: ParticipantProfile
  theme: 'light' | 'dark'
  onThemeChange: (t: 'light' | 'dark') => void
}

export function BadgePreviewCard({ profile, theme, onThemeChange }: BadgePreviewCardProps) {
  return (
    <div className="flex flex-col gap-5">
      {/* Segmented control — Stripe style, h-8, indigo active */}
      <div className="flex items-center gap-3">
        <span className="text-sm text-[#64748d]">Тема</span>
        <div
          className="flex h-8 rounded-lg p-[3px] gap-[2px]"
          role="group"
          aria-label="Выбор темы превью"
          style={{ background: '#f0f2f7', border: '1px solid #e5edf5' }}
        >
          {(['light', 'dark'] as const).map((t) => (
            <button
              key={t}
              onClick={() => onThemeChange(t)}
              aria-pressed={theme === t}
              className="h-full px-3 text-xs font-medium rounded-md transition-all"
              style={{
                background: theme === t ? '#533afd' : 'transparent',
                color:      theme === t ? '#ffffff' : '#64748d',
                boxShadow:  theme === t ? '0 1px 4px rgba(83,58,253,.25)' : 'none',
              }}
            >
              {t === 'light' ? 'Light' : 'Dark'}
            </button>
          ))}
        </div>
      </div>

      {/* Badge preview */}
      <div
        className="flex items-center justify-center rounded-[12px] p-8 transition-colors"
        style={{
          background: theme === 'dark'
            ? 'linear-gradient(135deg, #0d1520 0%, #0f1923 100%)'
            : 'linear-gradient(135deg, #f8fafd 0%, #eff4f9 100%)',
          border: `1px solid ${theme === 'dark' ? '#1e2f40' : '#e5edf5'}`,
          minHeight: 140,
        }}
      >
        <BadgeSvg profile={profile} theme={theme} />
      </div>

      {/* Size annotation */}
      <p className="text-[11px] text-[#9aa0a6] text-center">
        260 × 72 px · SVG · серверная подпись включена
      </p>
    </div>
  )
}
