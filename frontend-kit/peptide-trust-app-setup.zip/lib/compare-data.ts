import type { Tier } from '@/lib/catalog-data'

// ─── Factor codes & labels ────────────────────────────────────────────────
export const FACTOR_CODES = ['QEF','PCF','SCIF','TRF','FRF','CCF','CVF','CVF_B','RF'] as const
export type FactorCode = typeof FACTOR_CODES[number]

export const FACTOR_LABELS: Record<FactorCode, string> = {
  QEF:   'Качество & соответствие',
  PCF:   'Протокол чистоты',
  SCIF:  'Цепочка поставок',
  TRF:   'Прозрачность',
  FRF:   'Финансовая устойчивость',
  CCF:   'Соответствие нормам',
  CVF:   'Коммерческая ценность',
  CVF_B: 'Ценность бренда',
  RF:    'Репутация',
}

// ─── Types ───────────────────────────────────────────────────────────────
export interface CompareParticipant {
  id: string
  display_name: string
  role_code: string
  role_label: string
  score: number | null
  tier: Tier
  dominant_factor: FactorCode | null
  is_balanced: boolean
  verified_legal: boolean
  factors: Record<FactorCode, number>   // Fᵢ values 0–100
  independent_tests: number
  updated_days_ago: number
}

// ─── Tier thresholds ─────────────────────────────────────────────────────
export function scoreToTier(score: number): Tier {
  if (score >= 88) return 'Platinum'
  if (score >= 72) return 'Gold'
  if (score >= 55) return 'Silver'
  if (score >= 35) return 'Bronze'
  return 'Watch'
}

// ─── Mock participants ────────────────────────────────────────────────────
const MOCK_DB: Record<string, CompareParticipant> = {
  'p-001': {
    id: 'p-001',
    display_name: 'AlphaPep Lab',
    role_code: 'VENDOR_RUO',
    role_label: 'Вендор RUO',
    score: 94,
    tier: 'Platinum',
    dominant_factor: 'CCF',
    is_balanced: false,
    verified_legal: true,
    independent_tests: 18,
    updated_days_ago: 3,
    factors: {
      QEF: 95, PCF: 91, SCIF: 88, TRF: 92,
      FRF: 90, CCF: 96, CVF: 89, CVF_B: 93, RF: 94,
    },
  },
  'p-002': {
    id: 'p-002',
    display_name: 'BioSynth RU',
    role_code: 'VENDOR_RUO',
    role_label: 'Вендор RUO',
    score: 81,
    tier: 'Gold',
    dominant_factor: 'TRF',
    is_balanced: false,
    verified_legal: true,
    independent_tests: 11,
    updated_days_ago: 14,
    factors: {
      QEF: 78, PCF: 85, SCIF: 72, TRF: 92,
      FRF: 80, CCF: 75, CVF: 82, CVF_B: 79, RF: 77,
    },
  },
  'p-005': {
    id: 'p-005',
    display_name: 'ProBio Synth',
    role_code: 'VENDOR_RUO',
    role_label: 'Вендор RUO',
    score: 73,
    tier: 'Gold',
    dominant_factor: 'QEF',
    is_balanced: false,
    verified_legal: false,
    independent_tests: 7,
    updated_days_ago: 28,
    factors: {
      QEF: 82, PCF: 71, SCIF: 68, TRF: 70,
      FRF: 74, CCF: 69, CVF: 75, CVF_B: 72, RF: 65,
    },
  },
  // Extras for "add participant" demo
  'p-003': {
    id: 'p-003',
    display_name: 'Meridian Pharma CH',
    role_code: 'VENDOR_PHARMA',
    role_label: 'Вендор Pharma',
    score: 82,
    tier: 'Gold',
    dominant_factor: 'QEF',
    is_balanced: false,
    verified_legal: true,
    independent_tests: 14,
    updated_days_ago: 7,
    factors: {
      QEF: 88, PCF: 80, SCIF: 77, TRF: 82,
      FRF: 78, CCF: 83, CVF: 79, CVF_B: 75, RF: 81,
    },
  },
  'p-004': {
    id: 'p-004',
    display_name: 'EuroPep Lab',
    role_code: 'VENDOR_RUO',
    role_label: 'Вендор RUO',
    score: 78,
    tier: 'Gold',
    dominant_factor: 'SCIF',
    is_balanced: false,
    verified_legal: true,
    independent_tests: 9,
    updated_days_ago: 21,
    factors: {
      QEF: 74, PCF: 76, SCIF: 88, TRF: 78,
      FRF: 72, CCF: 77, CVF: 73, CVF_B: 70, RF: 75,
    },
  },
}

// All searchable participants for the "add" dialog
export const ALL_PARTICIPANTS: Pick<CompareParticipant, 'id' | 'display_name' | 'role_label' | 'tier' | 'score'>[] =
  Object.values(MOCK_DB).map(({ id, display_name, role_label, tier, score }) => ({
    id, display_name, role_label, tier, score,
  }))

export function getCompareParticipants(ids: string[]): CompareParticipant[] {
  return ids
    .map((id) => MOCK_DB[id.trim()])
    .filter((p): p is CompareParticipant => Boolean(p))
    .slice(0, 5) // max 5 columns
}

// Sort by Score desc, then by avg Vᵢ coverage (sum of factors as proxy), then original order
export function sortByBRRank(participants: CompareParticipant[]): CompareParticipant[] {
  return [...participants].sort((a, b) => {
    const sa = a.score ?? 0
    const sb = b.score ?? 0
    if (sb !== sa) return sb - sa
    // tiebreak: total factor sum (proxy for Vᵢ coverage)
    const sumA = FACTOR_CODES.reduce((acc, f) => acc + a.factors[f], 0)
    const sumB = FACTOR_CODES.reduce((acc, f) => acc + b.factors[f], 0)
    return sumB - sumA
  })
}

// Find the best participant ID for each factor
export function getBestByFactor(participants: CompareParticipant[]): Record<FactorCode, string> {
  const result = {} as Record<FactorCode, string>
  for (const code of FACTOR_CODES) {
    let bestId = participants[0]?.id ?? ''
    let bestVal = -1
    for (const p of participants) {
      if (p.factors[code] > bestVal) {
        bestVal = p.factors[code]
        bestId = p.id
      }
    }
    result[code] = bestId
  }
  return result
}
