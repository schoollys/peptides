/**
 * lib/participants.ts — SINGLE SOURCE OF TRUTH for all participant data.
 *
 * catalog-data.ts and profile-data.ts re-export from here.
 * recent-entries.tsx reads PARTICIPANTS directly.
 */

// ─── Shared types ─────────────────────────────────────────────────────────────

export type Tier            = 'Platinum' | 'Gold' | 'Silver' | 'Bronze' | 'Watch'
export type RoleCode        = 'MANUFACTURER' | 'DISTRIBUTOR' | 'LABORATORY' | 'RETAILER' | 'CONSULTANT' | 'IMPORTER'
export type DominantFactor  = 'QEF' | 'PCF' | 'SCIF' | 'TRF' | 'FRF' | 'CCF' | 'CVF' | 'CVF_B' | 'RF' | null
export type ParticipantStatus = 'ACTIVE' | 'PROVISIONAL' | 'SUSPENDED'
export type KybLevel        = 'L0' | 'L1' | 'L2' | 'L3'
export type FlagSeverity    = 'INFO' | 'WARNING' | 'CRITICAL'
export type FlagStatus      = 'OPEN' | 'RESOLVED' | 'MONITORING'
export type DiClass         = 'A' | 'B' | 'C' | 'D'

// ─── MVP anchor roles ─────────────────────────────────────────────────────────
// Three anchor roles for EU/CH MVP scope:
//   MANUFACTURER → RUO-вендор (Research-Use-Only supplier)
//   LABORATORY   → Лаборатория-оракул (verification oracle)
//   DISTRIBUTOR  → GB-организатор (group-buy organizer)
// All other role codes are non-anchor (provisional coverage).

export const ANCHOR_ROLE_CODES: RoleCode[] = ['MANUFACTURER', 'LABORATORY', 'DISTRIBUTOR']

export const ANCHOR_ROLE_LABELS: Record<RoleCode, string> = {
  MANUFACTURER: 'RUO-вендор',
  LABORATORY:   'Лаборатория-оракул',
  DISTRIBUTOR:  'GB-организатор',
  RETAILER:     'Ритейлер',
  CONSULTANT:   'Консультант',
  IMPORTER:     'Импортёр',
}

// ─── Label maps ───────────────────────────────────────────────────────────────

export const ROLE_LABELS: Record<RoleCode, string> = {
  MANUFACTURER: 'RUO-вендор',
  DISTRIBUTOR:  'GB-организатор',
  LABORATORY:   'Лаборатория-оракул',
  RETAILER:     'Ритейлер',
  CONSULTANT:   'Консультант',
  IMPORTER:     'Импортёр',
}

export const FACTOR_LABELS: Record<NonNullable<DominantFactor>, string> = {
  QEF:   'Качество энзимов',
  PCF:   'Протокол чистоты',
  SCIF:  'Стабильность цепочек',
  TRF:   'Тепловая резистентность',
  FRF:   'Поглощение фрагментов',
  CCF:   'Контроль концентрации',
  CVF:   'Валидация компонентов',
  CVF_B: 'Валидация компонентов B',
  RF:    'Поглощающая фракция',
}

export const TIER_ORDER: Record<Tier, number> = {
  Platinum: 0, Gold: 1, Silver: 2, Bronze: 3, Watch: 4,
}

// ─── Tier threshold function (Platinum 88–100 / Gold 72–87 / Silver 55–71 / Bronze 35–54 / Watch <35) ──

export function scoreToTier(score: number | null): Tier {
  if (score === null) return 'Watch'
  if (score >= 88) return 'Platinum'
  if (score >= 72) return 'Gold'
  if (score >= 55) return 'Silver'
  if (score >= 35) return 'Bronze'
  return 'Watch'
}

// ─── Factor helpers ───────────────────────────────────────────────────────────

export interface FactorEntry {
  code: NonNullable<DominantFactor>
  label: string
  value: number
  v_i: number
  freshness_di: number
  di_class: DiClass
  contribution: number
}

export interface ScoreEvent {
  id: string
  score: number
  dominant_factor: DominantFactor
  algo_version: string
  anchor_hash: string
  computed_at: string
}

export interface Flag {
  id: string
  type: string
  severity: FlagSeverity
  status: FlagStatus
  message: string
  raised_at: string
}

function diClass(days: number): DiClass {
  if (days <= 7)  return 'A'
  if (days <= 30) return 'B'
  if (days <= 90) return 'C'
  return 'D'
}

function factor(
  code: NonNullable<DominantFactor>,
  value: number,
  v_i: number,
  freshness_di: number
): FactorEntry {
  return {
    code,
    label: FACTOR_LABELS[code],
    value,
    v_i,
    freshness_di,
    di_class: diClass(freshness_di),
    contribution: Math.round(value * v_i * 10) / 10,
  }
}

// ─── Canonical participant record ─────────────────────────────────────────────

export interface Participant {
  // --- identity ---
  id: string
  display_name: string
  role_code: RoleCode
  status: ParticipantStatus
  jurisdiction: string
  domain: string
  // --- verification ---
  verified_legal: boolean
  kyb_level: KybLevel
  // --- score ---
  score: number | null          // one decimal, e.g. 94.7
  tier: Tier                    // derived from score via scoreToTier()
  dominant_factor: DominantFactor
  is_balanced: boolean
  trust_ceiling: number
  // --- activity ---
  tests_count: number
  updated_days_ago: number
  // --- algo ---
  algo_version: string
  latest_anchor_hash: string
  // --- detail data ---
  factors: FactorEntry[]
  flags: Flag[]
  score_events: ScoreEvent[]
  isAnchorRole: boolean   // true = one of 3 MVP anchor roles (EU/CH scope)
  provisional_reason?: string
  contacts?: {
    website?: string
    email?:   string
    telegram?: string
  }
}

// ─── 12 canonical participants ────────────────────────────────────────────────

export const PARTICIPANTS: Participant[] = [
  // ── p-001 ── BioSynth Laboratories AG ─ Platinum 94.7
  {
    id: 'p-001',
    display_name: 'BioSynth Laboratories AG',
    role_code: 'LABORATORY',
    status: 'ACTIVE',
    jurisdiction: 'Швейцария (CH)',
    domain: 'biosynth-labs.eu',
    isAnchorRole: true,
    verified_legal: true,
    kyb_level: 'L3',
    score: 94.7,
    tier: 'Platinum',
    dominant_factor: 'PCF',
    is_balanced: false,
    trust_ceiling: 100,
    tests_count: 48,
    updated_days_ago: 2,
    algo_version: 'v2.4.1',
    latest_anchor_hash: '0x3a9f...c821',
    factors: [
      factor('PCF',  96, 0.98, 3),
      factor('QEF',  93, 0.95, 5),
      factor('SCIF', 91, 0.90, 8),
      factor('TRF',  88, 0.88, 12),
      factor('CCF',  85, 0.85, 15),
      factor('CVF',  82, 0.80, 20),
    ],
    flags: [],
    score_events: [
      { id: 'e-1', score: 94.7, dominant_factor: 'PCF', algo_version: 'v2.4.1', anchor_hash: '0x3a9f...c821', computed_at: '2026-06-18T09:12:00Z' },
      { id: 'e-2', score: 93.1, dominant_factor: 'PCF', algo_version: 'v2.4.0', anchor_hash: '0x2b8e...a410', computed_at: '2026-05-30T14:33:00Z' },
      { id: 'e-3', score: 91.4, dominant_factor: 'QEF', algo_version: 'v2.3.2', anchor_hash: '0x1c7d...f309', computed_at: '2026-04-15T08:00:00Z' },
      { id: 'e-4', score: 89.8, dominant_factor: 'QEF', algo_version: 'v2.3.2', anchor_hash: '0x0a6c...e208', computed_at: '2026-03-01T11:20:00Z' },
    ],
    contacts: { website: 'https://biosynth-labs.eu', email: 'contact@biosynth-labs.eu', telegram: '@biosynthlabs' },
  },

  // ── p-002 ── HelixCore GmbH ─ Platinum 91.2
  {
    id: 'p-002',
    display_name: 'HelixCore GmbH',
    role_code: 'MANUFACTURER',
    status: 'ACTIVE',
    jurisdiction: 'Германия (DE)',
    domain: 'helixcore.de',
    isAnchorRole: true,
    verified_legal: true,
    kyb_level: 'L3',
    score: 91.2,
    tier: 'Platinum',
    dominant_factor: null,
    is_balanced: true,
    trust_ceiling: 100,
    tests_count: 63,
    updated_days_ago: 1,
    algo_version: 'v2.4.1',
    latest_anchor_hash: '0x7e2a...b503',
    factors: [
      factor('QEF',  92, 0.96, 2),
      factor('PCF',  91, 0.95, 2),
      factor('SCIF', 90, 0.93, 3),
      factor('TRF',  91, 0.92, 3),
      factor('CCF',  90, 0.91, 4),
      factor('CVF',  92, 0.94, 2),
    ],
    flags: [
      { id: 'f-1', type: 'COMPLIANCE_NOTICE', severity: 'INFO', status: 'RESOLVED', message: 'Документы KYB обновлены согласно требованиям регулятора DE', raised_at: '2026-04-01T00:00:00Z' },
    ],
    score_events: [
      { id: 'e-1', score: 91.2, dominant_factor: null, algo_version: 'v2.4.1', anchor_hash: '0x7e2a...b503', computed_at: '2026-06-19T07:00:00Z' },
      { id: 'e-2', score: 90.5, dominant_factor: null, algo_version: 'v2.4.0', anchor_hash: '0x6d19...a402', computed_at: '2026-05-15T12:00:00Z' },
    ],
    contacts: { website: 'https://helixcore.de', email: 'info@helixcore.de', telegram: '@helixcoregmbh' },
  },

  // ── p-003 ── PeptideSource International ─ Gold 82.4
  {
    id: 'p-003',
    display_name: 'PeptideSource International',
    role_code: 'DISTRIBUTOR',
    status: 'ACTIVE',
    jurisdiction: 'Нидерланды (NL)',
    domain: 'peptidesource.eu',
    isAnchorRole: true,
    verified_legal: true,
    kyb_level: 'L2',
    score: 82.4,
    tier: 'Gold',
    dominant_factor: 'QEF',
    is_balanced: false,
    trust_ceiling: 90,
    tests_count: 29,
    updated_days_ago: 5,
    algo_version: 'v2.4.1',
    latest_anchor_hash: '0x5c08...9301',
    factors: [
      factor('QEF',  88, 0.93, 6),
      factor('PCF',  80, 0.85, 10),
      factor('SCIF', 75, 0.80, 14),
      factor('TRF',  72, 0.78, 18),
      factor('CCF',  70, 0.76, 22),
    ],
    flags: [],
    score_events: [
      { id: 'e-1', score: 82.4, dominant_factor: 'QEF', algo_version: 'v2.4.1', anchor_hash: '0x5c08...9301', computed_at: '2026-06-15T10:00:00Z' },
      { id: 'e-2', score: 80.1, dominant_factor: 'QEF', algo_version: 'v2.4.0', anchor_hash: '0x4b07...8200', computed_at: '2026-05-20T09:00:00Z' },
      { id: 'e-3', score: 78.9, dominant_factor: 'QEF', algo_version: 'v2.3.2', anchor_hash: '0x3a06...7109', computed_at: '2026-04-10T11:00:00Z' },
    ],
    contacts: { website: 'https://peptidesource.com', email: 'sales@peptidesource.com' },
  },

  // ── p-004 ── Nordic Biotech Supply ─ Gold 78.9
  {
    id: 'p-004',
    display_name: 'Nordic Biotech Supply',
    role_code: 'IMPORTER',
    status: 'ACTIVE',
    jurisdiction: 'Швеция (SE)',
    domain: 'nordicbiotec.se',
    isAnchorRole: false,
    verified_legal: true,
    kyb_level: 'L2',
    score: 78.9,
    tier: 'Gold',
    dominant_factor: 'SCIF',
    is_balanced: false,
    trust_ceiling: 90,
    tests_count: 17,
    updated_days_ago: 10,
    algo_version: 'v2.4.1',
    latest_anchor_hash: '0x4b11...a204',
    factors: [
      factor('SCIF', 85, 0.91, 11),
      factor('TRF',  80, 0.87, 13),
      factor('QEF',  76, 0.82, 16),
      factor('PCF',  72, 0.78, 20),
      factor('CCF',  68, 0.74, 25),
    ],
    flags: [],
    score_events: [
      { id: 'e-1', score: 78.9, dominant_factor: 'SCIF', algo_version: 'v2.4.1', anchor_hash: '0x4b11...a204', computed_at: '2026-06-10T08:00:00Z' },
      { id: 'e-2', score: 77.2, dominant_factor: 'SCIF', algo_version: 'v2.4.0', anchor_hash: '0x3a00...9103', computed_at: '2026-05-05T09:00:00Z' },
      { id: 'e-3', score: 75.8, dominant_factor: 'SCIF', algo_version: 'v2.3.2', anchor_hash: '0x28ff...8002', computed_at: '2026-04-01T10:00:00Z' },
    ],
    contacts: { website: 'https://nordicbiotec.se', email: 'office@nordicbiotec.se', telegram: '@nordicbiotec' },
  },

  // ── p-005 ── Quantum Peptides LLC ─ Silver 71.3
  {
    id: 'p-005',
    display_name: 'Quantum Peptides GmbH',
    role_code: 'MANUFACTURER',
    status: 'ACTIVE',
    jurisdiction: 'Австрия (AT)',
    domain: 'qpeptides.eu',
    isAnchorRole: true,
    verified_legal: false,
    kyb_level: 'L1',
    score: 71.3,
    tier: 'Silver',
    dominant_factor: 'TRF',
    is_balanced: false,
    trust_ceiling: 80,
    tests_count: 22,
    updated_days_ago: 8,
    algo_version: 'v2.4.1',
    latest_anchor_hash: '0x9f44...d612',
    factors: [
      factor('TRF',  78, 0.92, 9),
      factor('PCF',  70, 0.82, 15),
      factor('QEF',  68, 0.78, 20),
      factor('SCIF', 62, 0.70, 25),
    ],
    flags: [
      { id: 'f-1', type: 'KYB_INCOMPLETE', severity: 'WARNING', status: 'OPEN', message: 'Уровень KYB L1 — предоставьте юридические документы для повышения до L2', raised_at: '2026-05-10T00:00:00Z' },
    ],
    score_events: [
      { id: 'e-1', score: 71.3, dominant_factor: 'TRF', algo_version: 'v2.4.1', anchor_hash: '0x9f44...d612', computed_at: '2026-06-12T08:00:00Z' },
      { id: 'e-2', score: 69.8, dominant_factor: 'TRF', algo_version: 'v2.4.0', anchor_hash: '0x8e33...c511', computed_at: '2026-05-01T09:00:00Z' },
    ],
    contacts: { website: 'https://qpeptides.io', telegram: '@qpeptides' },
  },

  // ── p-006 ── Meridian Pharma Consulting ─ Silver 68.1
  {
    id: 'p-006',
    display_name: 'Meridian Pharma Consulting',
    role_code: 'CONSULTANT',
    status: 'ACTIVE',
    jurisdiction: 'Франция (FR)',
    domain: 'meridian-pharma.eu',
    isAnchorRole: false,
    verified_legal: true,
    kyb_level: 'L2',
    score: 68.1,
    tier: 'Silver',
    dominant_factor: 'CVF',
    is_balanced: false,
    trust_ceiling: 90,
    tests_count: 11,
    updated_days_ago: 14,
    algo_version: 'v2.4.1',
    latest_anchor_hash: '0xd813...f401',
    factors: [
      factor('CVF',  74, 0.90, 15),
      factor('QEF',  68, 0.85, 18),
      factor('PCF',  65, 0.80, 22),
      factor('CCF',  60, 0.75, 28),
    ],
    flags: [],
    score_events: [
      { id: 'e-1', score: 68.1, dominant_factor: 'CVF', algo_version: 'v2.4.1', anchor_hash: '0xd813...f401', computed_at: '2026-06-06T09:00:00Z' },
      { id: 'e-2', score: 66.5, dominant_factor: 'CVF', algo_version: 'v2.4.0', anchor_hash: '0xc702...e300', computed_at: '2026-05-10T10:00:00Z' },
    ],
    contacts: { website: 'https://meridian-pharma.ru', email: 'info@meridian-pharma.ru' },
  },

  // ── p-007 ── ChainStable Bioworks ─ Silver 65.8
  {
    id: 'p-007',
    display_name: 'ChainStable Bioworks',
    role_code: 'MANUFACTURER',
    status: 'ACTIVE',
    jurisdiction: 'Нидерланды (NL)',
    domain: 'chainstable.bio',
    isAnchorRole: true,
    verified_legal: true,
    kyb_level: 'L2',
    score: 65.8,
    tier: 'Silver',
    dominant_factor: null,
    is_balanced: true,
    trust_ceiling: 90,
    tests_count: 34,
    updated_days_ago: 3,
    algo_version: 'v2.4.1',
    latest_anchor_hash: '0xc701...e200',
    factors: [
      factor('QEF',  67, 0.89, 4),
      factor('PCF',  66, 0.87, 4),
      factor('SCIF', 65, 0.86, 5),
      factor('TRF',  65, 0.85, 5),
      factor('CCF',  66, 0.86, 4),
    ],
    flags: [],
    score_events: [
      { id: 'e-1', score: 65.8, dominant_factor: null, algo_version: 'v2.4.1', anchor_hash: '0xc701...e200', computed_at: '2026-06-17T11:00:00Z' },
      { id: 'e-2', score: 64.2, dominant_factor: null, algo_version: 'v2.4.0', anchor_hash: '0xb600...d109', computed_at: '2026-05-22T12:00:00Z' },
      { id: 'e-3', score: 62.9, dominant_factor: 'QEF', algo_version: 'v2.3.2', anchor_hash: '0xa5ff...c008', computed_at: '2026-04-18T08:00:00Z' },
    ],
    contacts: { website: 'https://chainstable.bio', email: 'hello@chainstable.bio', telegram: '@chainstablebio' },
  },

  // ── p-008 ── EastMed Distributors ─ Silver 57.4
  {
    id: 'p-008',
    display_name: 'EuroMed Distributors',
    role_code: 'DISTRIBUTOR',
    status: 'ACTIVE',
    jurisdiction: 'Германия (DE)',
    domain: 'euromed-dist.eu',
    isAnchorRole: true,
    verified_legal: false,
    kyb_level: 'L1',
    score: 57.4,
    tier: 'Silver',
    dominant_factor: 'CCF',
    is_balanced: false,
    trust_ceiling: 80,
    tests_count: 9,
    updated_days_ago: 21,
    algo_version: 'v2.4.1',
    latest_anchor_hash: '0xb512...d101',
    factors: [
      factor('CCF',  63, 0.88, 22),
      factor('QEF',  58, 0.80, 28),
      factor('PCF',  54, 0.75, 35),
      factor('TRF',  50, 0.70, 40),
    ],
    flags: [
      { id: 'f-1', type: 'KYB_INCOMPLETE', severity: 'WARNING', status: 'OPEN', message: 'KYB L1 — юридические документы не предоставлены', raised_at: '2026-05-20T00:00:00Z' },
    ],
    score_events: [
      { id: 'e-1', score: 57.4, dominant_factor: 'CCF', algo_version: 'v2.4.1', anchor_hash: '0xb512...d101', computed_at: '2026-05-30T08:00:00Z' },
      { id: 'e-2', score: 55.9, dominant_factor: 'CCF', algo_version: 'v2.4.0', anchor_hash: '0xa401...c000', computed_at: '2026-04-25T09:00:00Z' },
    ],
    contacts: { email: 'contact@eastmed-dist.com' },
  },

  // ── p-009 ── TheraPep Retail Chain ─ Bronze 52.0
  {
    id: 'p-009',
    display_name: 'TheraPep Retail Chain',
    role_code: 'RETAILER',
    status: 'ACTIVE',
    jurisdiction: 'Швейцария (CH)',
    domain: 'therapep.ch',
    isAnchorRole: false,
    verified_legal: true,
    kyb_level: 'L1',
    score: 52.0,
    tier: 'Bronze',
    dominant_factor: 'FRF',
    is_balanced: false,
    trust_ceiling: 80,
    tests_count: 7,
    updated_days_ago: 30,
    algo_version: 'v2.4.1',
    latest_anchor_hash: '0xa310...b901',
    factors: [
      factor('FRF',  58, 0.86, 31),
      factor('QEF',  52, 0.78, 38),
      factor('PCF',  48, 0.72, 44),
    ],
    flags: [
      { id: 'f-1', type: 'LOW_TEST_COUNT', severity: 'INFO', status: 'OPEN', message: 'Недостаточно независимых тестов (7 из рекомендованных 15)', raised_at: '2026-04-15T00:00:00Z' },
    ],
    score_events: [
      { id: 'e-1', score: 52.0, dominant_factor: 'FRF', algo_version: 'v2.4.1', anchor_hash: '0xa310...b901', computed_at: '2026-05-21T10:00:00Z' },
      { id: 'e-2', score: 50.3, dominant_factor: 'FRF', algo_version: 'v2.4.0', anchor_hash: '0x920f...a800', computed_at: '2026-04-10T11:00:00Z' },
    ],
    contacts: { website: 'https://therapep.shop', telegram: '@therapepshop' },
  },

  // ── p-010 ── ProPeptide Ventures ─ Watch (Provisional)
  {
    id: 'p-010',
    display_name: 'ProPeptide Ventures',
    role_code: 'IMPORTER',
    status: 'PROVISIONAL',
    jurisdiction: 'Кипр (CY)',
    domain: 'propeptide.eu',
    isAnchorRole: false,
    verified_legal: false,
    kyb_level: 'L0',
    score: null,
    tier: 'Watch',
    dominant_factor: null,
    is_balanced: false,
    trust_ceiling: 60,
    tests_count: 2,
    updated_days_ago: 4,
    algo_version: 'v2.4.1',
    latest_anchor_hash: '—',
    provisional_reason: 'Минимальный порог независимых тестов не достигнут (необходимо ≥ 5, получено 2). KYB-проверка не завершена (L0). Score будет рассчитан автоматически после накопления данных.',
    factors: [
      factor('QEF',  42, 0.50, 4),
      factor('PCF',  38, 0.45, 4),
    ],
    flags: [
      { id: 'f-1', type: 'PROVISIONAL_DATA', severity: 'WARNING', status: 'OPEN', message: 'Недостаточно данных для расчёта Trust Score', raised_at: '2026-06-16T00:00:00Z' },
      { id: 'f-2', type: 'KYB_MISSING', severity: 'CRITICAL', status: 'OPEN', message: 'KYB-идентификация не завершена — участник не может быть верифицирован', raised_at: '2026-06-16T00:00:00Z' },
    ],
    score_events: [],
    contacts: { website: 'https://propeptide.ventures', email: 'hello@propeptide.ventures' },
  },

  // ── p-011 ── NovaBio Analytics ─ Watch (Provisional)
  {
    id: 'p-011',
    display_name: 'NovaBio Analytics',
    role_code: 'LABORATORY',
    status: 'PROVISIONAL',
    jurisdiction: 'Нидерланды (NL)',
    domain: 'novabio-analytics.eu',
    isAnchorRole: true,
    verified_legal: true,
    kyb_level: 'L1',
    score: null,
    tier: 'Watch',
    dominant_factor: null,
    is_balanced: false,
    trust_ceiling: 80,
    tests_count: 3,
    updated_days_ago: 6,
    algo_version: 'v2.4.1',
    latest_anchor_hash: '—',
    provisional_reason: 'Накопление данных: необходимо ≥ 5 независимых тестов. Сейчас 3. Score будет рассчитан автоматически.',
    factors: [
      factor('QEF',  55, 0.60, 7),
      factor('PCF',  50, 0.55, 7),
      factor('SCIF', 48, 0.52, 8),
    ],
    flags: [
      { id: 'f-1', type: 'PROVISIONAL_DATA', severity: 'WARNING', status: 'OPEN', message: 'Недостаточно данных для расчёта Trust Score (3/5)', raised_at: '2026-06-14T00:00:00Z' },
    ],
    score_events: [],
    contacts: { website: 'https://novabio-analytics.net', email: 'contact@novabio-analytics.net' },
  },

  // ── p-012 ── PharmaGate RU ─ Watch 28.5
  {
    id: 'p-012',
    display_name: 'PharmaGate AT',
    role_code: 'DISTRIBUTOR',
    status: 'ACTIVE',
    jurisdiction: 'Австрия (AT)',
    domain: 'pharmagate.eu',
    isAnchorRole: true,
    verified_legal: false,
    kyb_level: 'L1',
    score: 28.5,
    tier: 'Watch',
    dominant_factor: 'RF',
    is_balanced: false,
    trust_ceiling: 80,
    tests_count: 14,
    updated_days_ago: 7,
    algo_version: 'v2.4.1',
    latest_anchor_hash: '0xcc91...e047',
    factors: [
      factor('RF',   45, 0.85, 8),
      factor('QEF',  38, 0.72, 15),
      factor('PCF',  30, 0.65, 22),
      factor('SCIF', 28, 0.60, 30),
    ],
    flags: [
      { id: 'f-1', type: 'SCORE_DECLINE', severity: 'CRITICAL', status: 'MONITORING', message: 'Trust Score снизился на 18.4 пунктов за последние 90 дней', raised_at: '2026-06-01T00:00:00Z' },
      { id: 'f-2', type: 'TEST_DISCREPANCY', severity: 'WARNING', status: 'OPEN', message: 'Обнаружены расхождения в 3 независимых тестах по фактору RF', raised_at: '2026-05-20T00:00:00Z' },
      { id: 'f-3', type: 'LEGAL_UNVERIFIED', severity: 'INFO', status: 'OPEN', message: 'Юридическая верификация не пройдена', raised_at: '2026-04-10T00:00:00Z' },
    ],
    score_events: [
      { id: 'e-1', score: 28.5, dominant_factor: 'RF', algo_version: 'v2.4.1', anchor_hash: '0xcc91...e047', computed_at: '2026-06-13T10:00:00Z' },
      { id: 'e-2', score: 44.8, dominant_factor: 'RF', algo_version: 'v2.4.0', anchor_hash: '0xbb80...d936', computed_at: '2026-05-10T09:00:00Z' },
      { id: 'e-3', score: 52.6, dominant_factor: 'QEF', algo_version: 'v2.3.2', anchor_hash: '0xaa6f...c825', computed_at: '2026-04-01T08:00:00Z' },
      { id: 'e-4', score: 56.6, dominant_factor: 'QEF', algo_version: 'v2.3.2', anchor_hash: '0x995e...b714', computed_at: '2026-03-01T07:00:00Z' },
    ],
    contacts: { website: 'https://pharmagate.ru', email: 'info@pharmagate.ru', telegram: '@pharmagateru' },
  },
]

// ─── Indexed lookup map ───────────────────────────────────────────────────────

export const PARTICIPANTS_BY_ID: Record<string, Participant> =
  Object.fromEntries(PARTICIPANTS.map(p => [p.id, p]))

export function getParticipant(id: string): Participant | null {
  return PARTICIPANTS_BY_ID[id] ?? null
}
