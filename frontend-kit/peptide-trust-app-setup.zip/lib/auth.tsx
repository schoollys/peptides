'use client'

import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  type ReactNode,
} from 'react'

// ── Mock user shape ───────────────────────────────────────────────────────────
export interface MockUser {
  email: string
  /** Initials derived from email for the avatar chip */
  initials: string
  /** Linked participant id for linking to /p/{id} */
  participantId: string
}

// ── Context shape ─────────────────────────────────────────────────────────────
interface AuthState {
  user: MockUser | null
  isLoggedIn: boolean
  login:  (email: string) => void
  logout: () => void
}

const STORAGE_KEY = 'pt_mock_auth'

function initialsFrom(email: string): string {
  const local = email.split('@')[0] ?? ''
  const parts = local.split(/[._-]/)
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase()
  }
  return local.slice(0, 2).toUpperCase()
}

const AuthContext = createContext<AuthState>({
  user: null,
  isLoggedIn: false,
  login:  () => {},
  logout: () => {},
})

// ── Provider ──────────────────────────────────────────────────────────────────
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<MockUser | null>(null)

  // Rehydrate from localStorage on mount (client only)
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY)
      if (raw) setUser(JSON.parse(raw) as MockUser)
    } catch {
      // localStorage unavailable (SSR, private mode) — stay logged out
    }
  }, [])

  const login = useCallback((email: string) => {
    const u: MockUser = {
      email,
      initials: initialsFrom(email),
      participantId: 'p-001',
    }
    setUser(u)
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(u)) } catch { /* ignore */ }
  }, [])

  const logout = useCallback(() => {
    setUser(null)
    try { localStorage.removeItem(STORAGE_KEY) } catch { /* ignore */ }
  }, [])

  return (
    <AuthContext.Provider value={{ user, isLoggedIn: !!user, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

// ── Hook ──────────────────────────────────────────────────────────────────────
export function useAuth(): AuthState {
  return useContext(AuthContext)
}
