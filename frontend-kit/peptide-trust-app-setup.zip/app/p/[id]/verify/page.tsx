import { redirect } from 'next/navigation'

interface Props {
  params: Promise<{ id: string }>
}

export default async function ProfileVerifyRedirect({ params }: Props) {
  const { id } = await params
  redirect(`/p/${id}?tab=integrity`)
}
