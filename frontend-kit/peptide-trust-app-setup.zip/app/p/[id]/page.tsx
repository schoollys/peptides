import { Suspense } from 'react'
import { ProfilePageClient } from '@/components/profile/profile-page-client'
import { ProfileSkeleton } from '@/components/profile/profile-skeleton'

interface Props {
  params: Promise<{ id: string }>
}

export default function ProfilePage({ params }: Props) {
  return (
    <Suspense fallback={<ProfileSkeleton />}>
      <ProfilePageClient params={params} />
    </Suspense>
  )
}
