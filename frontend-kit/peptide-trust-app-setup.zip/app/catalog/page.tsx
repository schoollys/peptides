import type { Metadata } from 'next'
import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'
import { CatalogGrid } from '@/components/catalog/catalog-grid'

export const metadata: Metadata = {
  title:       'Каталог участников — PeptideTrust',
  description: 'Сегментированный публичный каталог производителей, дистрибьюторов и лабораторий пептидного рынка с рейтингом Trust Score.',
}

export default function CatalogPage() {
  return (
    <>
      <Header />

      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        {/* Page header */}
        <div className="mb-8">
          <h1
            className="text-3xl font-semibold tracking-heading text-balance"
            style={{ color: '#061b31', letterSpacing: '-0.02em' }}
          >
            Каталог участников
          </h1>
          <p className="mt-2 text-sm leading-relaxed" style={{ color: '#64748d' }}>
            Публичный реестр производителей, дистрибьюторов, лабораторий и
            ритейлеров пептидного рынка с независимой оценкой Trust Score.
          </p>
        </div>

        {/* MVP scope banner */}
        <div
          className="mb-6 flex flex-wrap items-start gap-3 rounded-xl px-4 py-3"
          style={{
            background: 'rgba(91,120,168,.07)',
            border:     '1px solid rgba(91,120,168,.22)',
          }}
          role="note"
          aria-label="Скоуп MVP"
        >
          <span
            className="mt-0.5 shrink-0 rounded-full px-2 py-0.5 text-[11px] font-bold uppercase tracking-wide"
            style={{ background: 'rgba(91,120,168,.15)', color: '#5b78a8' }}
          >
            MVP
          </span>
          <p className="text-sm leading-relaxed" style={{ color: '#3c4f69' }}>
            <span className="font-semibold">EU / CH · Приоритетные роли:</span>{' '}
            на первом этапе реестр охватывает три якорные роли —{' '}
            <span className="font-medium">RUO-вендор</span>,{' '}
            <span className="font-medium">Лаборатория-оракул</span>,{' '}
            <span className="font-medium">GB-организатор</span>.{' '}
            Остальные роли находятся в провизорном покрытии и получат полный Trust Score в следующих фазах.
          </p>
        </div>

        {/* Filters + grid */}
        <CatalogGrid />
      </main>

      <Footer />
    </>
  )
}
