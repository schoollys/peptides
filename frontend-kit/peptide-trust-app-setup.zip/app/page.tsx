import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'
import { Hero } from '@/components/home/hero'
import { Features } from '@/components/home/features'
import { SupplierCTA } from '@/components/home/supplier-cta'
import { RecentEntries } from '@/components/home/recent-entries'

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <Hero />
        <Features />
        <SupplierCTA />
        <RecentEntries />
      </main>
      <Footer />
    </div>
  )
}
