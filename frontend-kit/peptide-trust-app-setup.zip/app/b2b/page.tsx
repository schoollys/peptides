'use client'

import Link from 'next/link'
import {
  FileSearch,
  Bell,
  BarChart3,
  Plug,
  ShieldCheck,
  ArrowRight,
  Users,
  Lock,
  ChevronRight,
} from 'lucide-react'
import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'

// ── SKU definitions ────────────────────────────────────────────────────────────
const SKUS = [
  {
    slug:       'due-diligence',
    icon:       FileSearch,
    iconBg:     'rgba(83,58,253,.10)',
    iconColor:  '#533afd',
    name:       'Due-diligence отчёты',
    audience:   'Клиники, дистрибьюторы, prescribers',
    pitch:      'Принимаете решение о сотрудничестве с поставщиком? Получите полный срез: история факторов доверия, флаги нарушений, динамика Score, цепочка верификации и сравнение с тиром.',
    includes: [
      'История изменений Trust Score за 12 месяцев',
      'Флаги и решения апелляционной панели',
      'Цепочка верификации (KYB/KYC уровни)',
      'Сравнение с медианой тира и сегмента',
      'Экспорт в PDF / структурированный JSON',
    ],
  },
  {
    slug:       'monitoring-api',
    icon:       Bell,
    iconBg:     'rgba(0,130,80,.09)',
    iconColor:  '#007840',
    name:       'Мониторинг-API / вебхуки',
    audience:   'B2B-покупатели, платформы, агрегаторы',
    pitch:      'Подпишитесь на изменения Score и флагов ваших контрагентов. Вебхук уходит в течение минут после пересчёта — ваша система реагирует автоматически.',
    includes: [
      'Вебхуки на изменение Score ±N пунктов',
      'Push-уведомления о новых флагах и решениях',
      'REST API: актуальный Score по participant_id',
      'Пакетный запрос до 500 участников за раз',
      'SLA 99.9 % и тестовая среда (sandbox)',
    ],
  },
  {
    slug:       'market-analytics',
    icon:       BarChart3,
    iconBg:     'rgba(201,162,39,.10)',
    iconColor:  '#8a6800',
    name:       'Рыночная аналитика',
    audience:   'Исследователи, инвесторы, регуляторы',
    pitch:      'Агрегированные тренды ниши без раскрытия данных отдельных участников. Мониторинг здоровья рынка, распределение по тирам, динамика инцидентов.',
    includes: [
      'Агрегированное распределение Score по сегментам',
      'Динамика инцидентов и апелляций (отраслевой уровень)',
      'Сравнение тиров: медианы, квартили, выбросы',
      'Ежемесячные отчёты в формате XLSX / API',
      'Данные только агрегированные — без личных профилей',
    ],
  },
  {
    slug:       'verification-as-a-service',
    icon:       Plug,
    iconBg:     'rgba(83,58,253,.07)',
    iconColor:  '#533afd',
    name:       'Verification-as-a-Service',
    audience:   'Маркетплейсы, форумы, торговые площадки',
    pitch:      'Встройте проверку Trust Score в свою платформу. Бейдж PeptideTrust подтверждает подлинность участника вашим пользователям без перехода на внешний сайт.',
    includes: [
      'Встраиваемый бейдж (iframe / Web Component)',
      'REST + GraphQL API верификации',
      'JavaScript SDK с готовыми компонентами',
      'Webhook-уведомления об изменении статуса',
      'White-label опция по согласованию',
    ],
  },
]

// ── Tier multipliers for insight block ────────────────────────────────────────
const TIER_REACH: { tier: string; color: string; multiplier: string }[] = [
  { tier: 'Platinum', color: '#4a1fa8', multiplier: '3.8×' },
  { tier: 'Gold',     color: '#7a5000', multiplier: '2.4×' },
  { tier: 'Silver',   color: '#404040', multiplier: '1.5×' },
  { tier: 'Bronze',   color: '#7a3800', multiplier: '1.0×' },
]

// ── Page ──────────────────────────────────────────────────────────────────────
export default function B2BPage() {
  return (
    <>
      <title>Для организаций — PeptideTrust B2B</title>
      <div className="flex min-h-screen flex-col" style={{ background: '#f8fafd' }}>
        <Header />

        <main className="flex-1">

          {/* ── Hero ──────────────────────────────────────────────────────── */}
          <section
            className="border-b"
            style={{
              background: 'linear-gradient(180deg, #eef2ff 0%, #f8fafd 100%)',
              borderColor: '#e5edf5',
            }}
          >
            <div className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8 sm:py-20 text-center">

              {/* Neutrality badge */}
              <div className="mb-6 inline-flex items-center gap-2 rounded-full px-3.5 py-1.5"
                style={{
                  background: '#e8e9ff',
                  border: '1px solid rgba(83,58,253,.22)',
                }}>
                <ShieldCheck size={13} style={{ color: '#533afd' }} strokeWidth={2.2} />
                <span className="text-xs font-semibold" style={{ color: '#533afd' }}>
                  Нейтральная платформа · платит потребитель информации
                </span>
              </div>

              <h1
                className="text-balance text-3xl font-semibold sm:text-4xl"
                style={{ color: '#061b31', letterSpacing: '-0.02em', lineHeight: 1.15 }}
              >
                PeptideTrust для организаций
              </h1>
              <p
                className="mx-auto mt-4 max-w-2xl text-base leading-relaxed"
                style={{ color: '#50617a' }}
              >
                Инструменты проверки контрагентов, мониторинга и рыночной аналитики для
                профессиональных участников рынка. Подходит для клиник, дистрибьюторов,
                маркетплейсов и регуляторов.
              </p>

              {/* Model note */}
              <div
                className="mx-auto mt-8 max-w-xl rounded-xl px-5 py-4 text-left"
                style={{
                  background: 'white',
                  border: '1px solid #dde6f0',
                  boxShadow: '0 2px 10px 0 rgba(0,55,112,.06)',
                }}
              >
                <div className="flex items-start gap-3">
                  <div
                    className="mt-0.5 flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg"
                    style={{ background: '#f0f0ff' }}
                  >
                    <Users size={14} style={{ color: '#533afd' }} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold" style={{ color: '#061b31' }}>
                      Модель: платит решающий, не оцениваемый
                    </p>
                    <p className="mt-1 text-xs leading-relaxed" style={{ color: '#64748d' }}>
                      Доступ к данным оплачивает тот, кто принимает решение (клиника,
                      инвестор, платформа). Участник реестра не может оплатить улучшение
                      своего Trust Score или скрыть флаги.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* ── SKU grid ──────────────────────────────────────────────────── */}
          <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
            <h2
              className="mb-2 text-xl font-semibold"
              style={{ color: '#061b31', letterSpacing: '-0.01em' }}
            >
              Продукты и решения
            </h2>
            <p className="mb-10 text-sm" style={{ color: '#64748d' }}>
              Без цен и обязательств — подайте запрос и мы пришлём детали.
            </p>

            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
              {SKUS.map((sku) => {
                const Icon = sku.icon
                return (
                  <article
                    key={sku.slug}
                    className="flex flex-col rounded-2xl bg-white"
                    style={{
                      border: '1px solid #e5edf5',
                      boxShadow: '0 2px 10px 0 rgba(0,55,112,.06), 0 1px 4px 0 rgba(0,59,137,.04)',
                    }}
                  >
                    <div className="flex-1 px-6 pt-6 pb-5">
                      {/* Icon + name */}
                      <div className="mb-4 flex items-start gap-3">
                        <div
                          className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl"
                          style={{ background: sku.iconBg }}
                        >
                          <Icon size={20} style={{ color: sku.iconColor }} strokeWidth={1.7} />
                        </div>
                        <div>
                          <h3
                            className="text-base font-semibold leading-snug"
                            style={{ color: '#061b31', letterSpacing: '-0.01em' }}
                          >
                            {sku.name}
                          </h3>
                          <p className="mt-0.5 text-xs font-medium" style={{ color: sku.iconColor }}>
                            {sku.audience}
                          </p>
                        </div>
                      </div>

                      {/* Pitch */}
                      <p className="mb-5 text-sm leading-relaxed" style={{ color: '#50617a' }}>
                        {sku.pitch}
                      </p>

                      {/* Includes list */}
                      <ul className="flex flex-col gap-2">
                        {sku.includes.map((item) => (
                          <li key={item} className="flex items-start gap-2">
                            <ChevronRight
                              size={13}
                              className="mt-0.5 flex-shrink-0"
                              style={{ color: '#a0aec0' }}
                            />
                            <span className="text-xs leading-relaxed" style={{ color: '#3c4f69' }}>
                              {item}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* CTA */}
                    <div
                      className="px-6 pb-6"
                    >
                      <Link
                        href={`/b2b/request?sku=${sku.slug}`}
                        className="inline-flex items-center gap-1.5 rounded-[10px] px-4 py-2.5 text-sm font-medium transition-colors"
                        style={{
                          background: '#533afd',
                          color: 'white',
                        }}
                        onMouseEnter={e => {
                          (e.currentTarget as HTMLElement).style.background = '#4429e8'
                        }}
                        onMouseLeave={e => {
                          (e.currentTarget as HTMLElement).style.background = '#533afd'
                        }}
                      >
                        Запросить доступ
                        <ArrowRight size={14} />
                      </Link>
                    </div>
                  </article>
                )
              })}
            </div>
          </section>

          {/* ── Tier reach insight ────────────────────────────────────────── */}
          <section
            className="border-y"
            style={{ background: 'white', borderColor: '#e5edf5' }}
          >
            <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:px-8">
              <div className="flex flex-col gap-8 lg:flex-row lg:items-center lg:gap-16">
                <div className="flex-1">
                  <p className="mb-1 text-xs font-semibold uppercase tracking-widest" style={{ color: '#7d8ba4' }}>
                    ROI для ваших контрагентов
                  </p>
                  <h2
                    className="text-xl font-semibold"
                    style={{ color: '#061b31', letterSpacing: '-0.01em' }}
                  >
                    Поставщики с высоким Score получают кратно больше входящих обращений
                  </h2>
                  <p className="mt-3 text-sm leading-relaxed" style={{ color: '#50617a' }}>
                    Mock-оценка по данным каталога: участники Platinum-тира в среднем получают
                    в 3.8× больше обращений через платформу, чем Bronze. Данные агрегированные —
                    без раскрытия профилей.
                  </p>
                </div>
                <div className="flex flex-col gap-3 lg:min-w-[260px]">
                  {TIER_REACH.map(({ tier, color, multiplier }) => (
                    <div key={tier} className="flex items-center gap-3">
                      <span
                        className="w-16 text-right text-xs font-semibold tabular-nums"
                        style={{ color }}
                      >
                        {tier}
                      </span>
                      <div
                        className="h-2 flex-1 overflow-hidden rounded-full"
                        style={{ background: '#eef2ff' }}
                      >
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${(parseFloat(multiplier) / 3.8) * 100}%`,
                            background: color,
                            opacity: 0.7,
                          }}
                        />
                      </div>
                      <span className="w-10 text-xs font-semibold tabular-nums" style={{ color }}>
                        {multiplier}
                      </span>
                    </div>
                  ))}
                  <p className="mt-1 text-[11px] leading-relaxed" style={{ color: '#95a4ba' }}>
                    Условный индекс обращений, base = Bronze. Данные за 30 дней.
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* ── Neutrality callout ────────────────────────────────────────── */}
          <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6 lg:px-8">
            <div
              className="rounded-2xl px-7 py-7"
              style={{
                background: '#f0f0ff',
                border: '1px solid rgba(83,58,253,.18)',
              }}
            >
              <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:gap-6">
                <div
                  className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl"
                  style={{ background: '#e8e9ff', border: '1px solid rgba(83,58,253,.22)' }}
                >
                  <Lock size={20} style={{ color: '#533afd' }} strokeWidth={1.8} />
                </div>
                <div>
                  <h2
                    className="mb-2 text-base font-semibold"
                    style={{ color: '#2a1e7a', letterSpacing: '-0.01em' }}
                  >
                    Граница нейтралитета
                  </h2>
                  <p className="text-sm leading-relaxed" style={{ color: '#3c3870' }}>
                    <strong>Платит потребитель информации, не объект оценки.</strong>{' '}
                    Ни один из представленных продуктов не позволяет участнику реестра
                    оплатить повышение своего Trust Score, скрыть флаги или влиять на решения
                    апелляционной панели. Аналитические продукты оперируют только
                    агрегированными данными — без продажи влияния на конкретный профиль.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {[
                      'Score не продаётся',
                      'Флаги нельзя скрыть',
                      'Аналитика — только агрегаты',
                      'Один источник правды',
                    ].map((tag) => (
                      <span
                        key={tag}
                        className="rounded-full px-2.5 py-1 text-[11px] font-medium"
                        style={{
                          background: 'rgba(83,58,253,.10)',
                          color: '#533afd',
                          border: '1px solid rgba(83,58,253,.18)',
                        }}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

        </main>

        <Footer />
      </div>
    </>
  )
}
