'use client'

import { useState, useEffect, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import {
  FileSearch, Bell, BarChart3, Plug,
  CheckCircle2, Loader2, AlertCircle, ArrowLeft, Info,
} from 'lucide-react'
import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

// ── SKU metadata ──────────────────────────────────────────────────────────────
const SKU_META: Record<string, {
  label: string
  icon: React.ElementType
  color: string
  rgb: string
}> = {
  'due-diligence':             { label: 'Due-diligence отчёты',        icon: FileSearch, color: '#533afd', rgb: '83,58,253'   },
  'monitoring-api':            { label: 'Мониторинг-API / вебхуки',    icon: Bell,       color: '#007840', rgb: '0,120,64'    },
  'market-analytics':          { label: 'Рыночная аналитика',          icon: BarChart3,  color: '#8a6800', rgb: '138,104,0'   },
  'verification-as-a-service': { label: 'Verification-as-a-Service',   icon: Plug,       color: '#533afd', rgb: '83,58,253'   },
}
const SKU_SLUGS = Object.keys(SKU_META)

// ── Roles ─────────────────────────────────────────────────────────────────────
const ROLES = [
  { value: 'clinic',        label: 'Клиника / медицинская организация' },
  { value: 'distributor',   label: 'Дистрибьютор' },
  { value: 'prescriber',    label: 'Prescriber / практикующий врач' },
  { value: 'marketplace',   label: 'Маркетплейс' },
  { value: 'researcher',    label: 'Исследователь / академия' },
  { value: 'investor',      label: 'Инвестор / фонд' },
  { value: 'regulator',     label: 'Регулятор / госорган' },
  { value: 'other',         label: 'Другое' },
]

// ── Volumes ───────────────────────────────────────────────────────────────────
const VOLUMES = [
  { value: 'trial',         label: 'Пилот / единичные запросы' },
  { value: 'low',           label: 'До 100 запросов в месяц' },
  { value: 'medium',        label: '100–1 000 запросов в месяц' },
  { value: 'high',          label: '1 000–10 000 запросов в месяц' },
  { value: 'enterprise',    label: 'Более 10 000 запросов в месяц' },
  { value: 'custom',        label: 'Требуется обсудить' },
]

// ── Public email domains (soft warning only) ──────────────────────────────────
const PUBLIC_DOMAINS = new Set([
  'gmail.com', 'yahoo.com', 'yahoo.ru', 'yandex.ru', 'yandex.com',
  'mail.ru', 'hotmail.com', 'outlook.com', 'bk.ru', 'list.ru',
  'inbox.ru', 'icloud.com', 'protonmail.com', 'proton.me',
])

function isPublicEmail(email: string): boolean {
  const domain = email.split('@')[1]?.toLowerCase().trim()
  return !!domain && PUBLIC_DOMAINS.has(domain)
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function generateRefId(): string {
  return 'B2B-' + Math.random().toString(36).slice(2, 8).toUpperCase()
}

interface LeadRecord {
  refId:     string
  sku:       string
  org:       string
  email:     string
  role:      string
  volume:    string
  task:      string
  ts:        string
}

const LS_KEY = 'pt_b2b_leads'

function saveLead(lead: LeadRecord): void {
  try {
    const raw  = localStorage.getItem(LS_KEY)
    const list: LeadRecord[] = raw ? JSON.parse(raw) : []
    list.push(lead)
    localStorage.setItem(LS_KEY, JSON.stringify(list.slice(-200)))
  } catch {
    // localStorage unavailable
  }
}

// ── Field helpers ─────────────────────────────────────────────────────────────
function FieldLabel({ htmlFor, children, required }: {
  htmlFor: string
  children: React.ReactNode
  required?: boolean
}) {
  return (
    <label
      htmlFor={htmlFor}
      className="mb-1.5 block text-xs font-semibold"
      style={{ color: '#3c4f69' }}
    >
      {children}
      {required && <span style={{ color: '#d8351e' }}> *</span>}
      {!required && (
        <span className="ml-1 font-normal" style={{ color: '#95a4ba' }}>(необязательно)</span>
      )}
    </label>
  )
}

function FieldError({ msg }: { msg: string }) {
  return (
    <p
      className="mt-1.5 flex items-center gap-1.5 text-xs font-medium"
      style={{ color: '#d8351e' }}
      role="alert"
    >
      <AlertCircle size={11} className="shrink-0" />
      {msg}
    </p>
  )
}

// ── Main form (inner — uses useSearchParams) ──────────────────────────────────
function RequestForm() {
  const searchParams = useSearchParams()
  const paramSku     = searchParams.get('sku') ?? ''

  const [sku,      setSku]      = useState(SKU_SLUGS.includes(paramSku) ? paramSku : '')
  const [org,      setOrg]      = useState('')
  const [email,    setEmail]    = useState('')
  const [role,     setRole]     = useState('')
  const [volume,   setVolume]   = useState('')
  const [task,     setTask]     = useState('')
  const [consent,  setConsent]  = useState(false)

  const [errors,   setErrors]   = useState<Record<string, string>>({})
  const [softWarn, setSoftWarn] = useState(false)   // Gmail/public-domain hint
  const [loading,  setLoading]  = useState(false)
  const [serverErr,setServerErr]= useState(false)
  const [refId,    setRefId]    = useState('')

  // Re-sync if URL param changes
  useEffect(() => {
    const p = searchParams.get('sku') ?? ''
    if (SKU_SLUGS.includes(p)) setSku(p)
  }, [searchParams])

  // Soft email domain warning on blur
  function handleEmailBlur() {
    if (email && email.includes('@')) {
      setSoftWarn(isPublicEmail(email))
    }
  }

  // ── Validation ──────────────────────────────────────────────────────────────
  function validate(): boolean {
    const e: Record<string, string> = {}
    if (!sku)                                    e.sku    = 'Выберите продукт'
    if (!org.trim())                             e.org    = 'Введите название организации'
    if (!email.trim())                           e.email  = 'Введите email'
    else if (!email.includes('@') || !email.includes('.'))
                                                 e.email  = 'Некорректный формат email'
    if (!role)                                   e.role   = 'Выберите роль'
    if (!consent)                                e.consent = 'Необходимо согласие на обработку данных'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  // ── Submit ──────────────────────────────────────────────────────────────────
  async function handleSubmit(ev: React.FormEvent) {
    ev.preventDefault()
    setServerErr(false)
    if (!validate()) return
    setLoading(true)
    await new Promise(r => setTimeout(r, 900))    // mock latency
    setLoading(false)
    const id = generateRefId()
    saveLead({ refId: id, sku, org, email, role, volume, task, ts: new Date().toISOString() })
    setRefId(id)
  }

  // ── Success state ───────────────────────────────────────────────────────────
  if (refId) {
    return (
      <div className="w-full" style={{ maxWidth: 480 }}>
        <div
          className="rounded-2xl bg-white px-8 py-10"
          style={{
            border:     '1px solid #e5edf5',
            boxShadow:  '0 6px 22px 0 rgba(0,55,112,.10), 0 4px 8px 0 rgba(0,59,137,.02)',
          }}
        >
          {/* Icon */}
          <div
            className="mb-5 flex h-12 w-12 items-center justify-center rounded-full"
            style={{ background: '#edfaf4' }}
          >
            <CheckCircle2 size={22} style={{ color: '#00844a' }} />
          </div>

          <h1
            className="text-xl font-semibold"
            style={{ color: '#061b31', letterSpacing: '-0.01em' }}
          >
            Заявка принята
          </h1>

          <p className="mt-2 text-sm leading-relaxed" style={{ color: '#50617a' }}>
            Мы свяжемся с вами на{' '}
            <span className="font-semibold" style={{ color: '#3c4f69' }}>{email}</span>{' '}
            в течение 2 рабочих дней.
          </p>

          {/* Ref ID row */}
          <div
            className="mt-5 flex items-center gap-3 rounded-lg px-4 py-3"
            style={{ background: '#f8fafd', border: '1px solid #e5edf5' }}
          >
            <span className="text-xs" style={{ color: '#64748d' }}>ID заявки</span>
            <span
              className="ml-auto font-mono text-sm font-semibold tabular-nums"
              style={{ color: '#533afd' }}
            >
              {refId}
            </span>
          </div>

          {/* Fine print */}
          <p
            className="mt-4 rounded-lg px-3 py-2.5 text-xs leading-relaxed"
            style={{ background: 'rgba(83,58,253,.05)', color: '#50617a' }}
          >
            Платформа нейтральна: мы не продаём продукты и не связываем вас с конкретными участниками без вашего явного согласия.
          </p>

          {/* CTAs */}
          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              href="/b2b"
              className="inline-flex items-center gap-1.5 rounded-[10px] px-4 py-2.5 text-sm font-medium transition-opacity hover:opacity-90"
              style={{ background: '#533afd', color: 'white' }}
            >
              <ArrowLeft size={13} />
              Вернуться к B2B
            </Link>
            <Link
              href="/"
              className="inline-flex items-center gap-1.5 rounded-[10px] px-4 py-2.5 text-sm font-medium"
              style={{ background: '#f0f2f6', color: '#3c4f69' }}
            >
              На главную
            </Link>
          </div>
        </div>
      </div>
    )
  }

  // ── Form ───────────────────────────────────────────────────────────────────
  return (
    <div className="w-full" style={{ maxWidth: 540 }}>
      {/* Back link */}
      <Link
        href="/b2b"
        className="mb-6 inline-flex items-center gap-1.5 text-sm transition-colors hover:underline"
        style={{ color: '#64748d' }}
      >
        <ArrowLeft size={14} />
        Все продукты B2B
      </Link>

      <div
        className="rounded-2xl bg-white px-8 py-9"
        style={{
          border:    '1px solid #e5edf5',
          boxShadow: '0 6px 22px 0 rgba(0,55,112,.10), 0 4px 8px 0 rgba(0,59,137,.02)',
        }}
      >
        <h1
          className="mb-1 text-xl font-semibold"
          style={{ color: '#061b31', letterSpacing: '-0.01em' }}
        >
          Запросить доступ
        </h1>
        <p className="mb-7 text-sm leading-relaxed" style={{ color: '#64748d' }}>
          Без цен и обязательств — ответим на вопросы и пришлём детали.
        </p>

        {/* Server error */}
        {serverErr && (
          <div
            className="mb-5 flex items-center gap-2 rounded-lg px-3 py-3"
            style={{ background: '#fef3f1', border: '1px solid #f8c8c2' }}
            role="alert"
          >
            <AlertCircle size={14} className="shrink-0" style={{ color: '#d8351e' }} />
            <span className="text-xs" style={{ color: '#b02010' }}>
              Не удалось отправить запрос. Попробуйте ещё раз.
            </span>
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-5">

          {/* ── 1. SKU selector ───────────────────────────────────────────── */}
          <div>
            <FieldLabel htmlFor="req-sku" required>Продукт</FieldLabel>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2" role="group" aria-label="Выберите продукт">
              {SKU_SLUGS.map((slug) => {
                const meta     = SKU_META[slug]
                const Icon     = meta.icon
                const selected = sku === slug
                return (
                  <button
                    key={slug}
                    type="button"
                    onClick={() => {
                      setSku(slug)
                      if (errors.sku) setErrors(p => ({ ...p, sku: '' }))
                    }}
                    className="flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-left transition-all"
                    style={{
                      border:     `1.5px solid ${selected ? meta.color : '#dde6f0'}`,
                      background: selected ? `rgba(${meta.rgb},.07)` : 'white',
                    }}
                    aria-pressed={selected}
                  >
                    <div
                      className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg"
                      style={{ background: selected ? meta.color : '#f0f2f6' }}
                    >
                      <Icon size={13} style={{ color: selected ? 'white' : '#64748d' }} strokeWidth={1.8} />
                    </div>
                    <span
                      className="text-xs font-medium leading-snug"
                      style={{ color: selected ? '#061b31' : '#50617a' }}
                    >
                      {meta.label}
                    </span>
                  </button>
                )
              })}
            </div>
            {errors.sku && <FieldError msg={errors.sku} />}
          </div>

          {/* ── 2. Organisation ──────────────────────────────────────────── */}
          <div>
            <FieldLabel htmlFor="req-org" required>Компания / организация</FieldLabel>
            <Input
              id="req-org"
              placeholder="ООО «Клиника Пример»"
              autoComplete="organization"
              value={org}
              onChange={e => { setOrg(e.target.value); if (errors.org) setErrors(p => ({ ...p, org: '' })) }}
              aria-invalid={!!errors.org}
              style={errors.org ? { borderColor: '#d8351e', boxShadow: '0 0 0 3px rgba(216,53,30,.12)' } : undefined}
            />
            {errors.org && <FieldError msg={errors.org} />}
          </div>

          {/* ── 3. Email ─────────────────────────────────────────────────── */}
          <div>
            <FieldLabel htmlFor="req-email" required>Рабочий email</FieldLabel>
            <Input
              id="req-email"
              type="email"
              placeholder="you@company.com"
              autoComplete="email"
              value={email}
              onChange={e => {
                setEmail(e.target.value)
                if (errors.email) setErrors(p => ({ ...p, email: '' }))
                if (softWarn && !isPublicEmail(e.target.value)) setSoftWarn(false)
              }}
              onBlur={handleEmailBlur}
              aria-invalid={!!errors.email}
              style={errors.email ? { borderColor: '#d8351e', boxShadow: '0 0 0 3px rgba(216,53,30,.12)' } : undefined}
            />
            {errors.email && <FieldError msg={errors.email} />}
            {/* Soft warning — non-blocking */}
            {softWarn && !errors.email && (
              <div
                className="mt-1.5 flex items-start gap-1.5 rounded-lg px-3 py-2"
                style={{ background: 'rgba(201,162,39,.08)', border: '1px solid rgba(201,162,39,.25)' }}
              >
                <Info size={12} className="mt-0.5 shrink-0" style={{ color: '#c9a227' }} />
                <p className="text-xs leading-relaxed" style={{ color: '#7d5c00' }}>
                  Желательно рабочий email — это ускоряет квалификацию заявки.
                </p>
              </div>
            )}
          </div>

          {/* ── 4. Role (select) ─────────────────────────────────────────── */}
          <div>
            <FieldLabel htmlFor="req-role" required>Роль / тип организации</FieldLabel>
            <div className="relative">
              <select
                id="req-role"
                value={role}
                onChange={e => { setRole(e.target.value); if (errors.role) setErrors(p => ({ ...p, role: '' })) }}
                aria-invalid={!!errors.role}
                className="w-full appearance-none rounded-md border px-3 py-2.5 pr-9 text-sm outline-none transition-shadow focus:ring-2 focus:ring-[#533afd]/25"
                style={{
                  borderColor: errors.role ? '#d8351e' : '#dde6f0',
                  color:       role ? '#3c4f69' : '#95a4ba',
                  background:  'white',
                  boxShadow:   errors.role ? '0 0 0 3px rgba(216,53,30,.12)' : undefined,
                }}
              >
                <option value="" disabled>Выберите роль…</option>
                {ROLES.map(r => (
                  <option key={r.value} value={r.value}>{r.label}</option>
                ))}
              </select>
              {/* Chevron icon */}
              <svg
                className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2"
                width="14" height="14" viewBox="0 0 24 24"
                fill="none" stroke="#64748d" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
                aria-hidden="true"
              >
                <path d="m6 9 6 6 6-6" />
              </svg>
            </div>
            {errors.role && <FieldError msg={errors.role} />}
          </div>

          {/* ── 5. Volume / frequency (select, optional) ─────────────────── */}
          <div>
            <FieldLabel htmlFor="req-volume">Ориентировочный объём / частота</FieldLabel>
            <div className="relative">
              <select
                id="req-volume"
                value={volume}
                onChange={e => setVolume(e.target.value)}
                className="w-full appearance-none rounded-md border px-3 py-2.5 pr-9 text-sm outline-none transition-shadow focus:ring-2 focus:ring-[#533afd]/25"
                style={{
                  borderColor: '#dde6f0',
                  color:       volume ? '#3c4f69' : '#95a4ba',
                  background:  'white',
                }}
              >
                <option value="">Не указано</option>
                {VOLUMES.map(v => (
                  <option key={v.value} value={v.value}>{v.label}</option>
                ))}
              </select>
              <svg
                className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2"
                width="14" height="14" viewBox="0 0 24 24"
                fill="none" stroke="#64748d" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
                aria-hidden="true"
              >
                <path d="m6 9 6 6 6-6" />
              </svg>
            </div>
          </div>

          {/* ── 6. Task description (textarea, optional) ──────────────────── */}
          <div>
            <FieldLabel htmlFor="req-task">Краткое описание задачи</FieldLabel>
            <textarea
              id="req-task"
              rows={4}
              placeholder="Расскажите, что хотите решить, или задайте вопрос. Это поможет нам подготовить точный ответ."
              value={task}
              onChange={e => setTask(e.target.value)}
              maxLength={1200}
              className="w-full resize-none rounded-md border px-3 py-2.5 text-sm outline-none transition-shadow focus:ring-2 focus:ring-[#533afd]/25"
              style={{
                borderColor: '#dde6f0',
                color:       '#3c4f69',
                background:  'white',
                lineHeight:  '1.6',
              }}
            />
            <p
              className="mt-1 text-right text-[11px] tabular-nums"
              style={{ color: '#95a4ba' }}
            >
              {task.length} / 1200
            </p>
          </div>

          {/* ── 7. Consent checkbox ──────────────────────────────────────── */}
          <div>
            <label
              className="flex cursor-pointer items-start gap-3"
              htmlFor="req-consent"
            >
              <div className="relative mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center">
                <input
                  type="checkbox"
                  id="req-consent"
                  checked={consent}
                  onChange={e => {
                    setConsent(e.target.checked)
                    if (errors.consent) setErrors(p => ({ ...p, consent: '' }))
                  }}
                  className="peer absolute h-4 w-4 cursor-pointer opacity-0"
                  aria-invalid={!!errors.consent}
                />
                {/* Custom checkbox face */}
                <div
                  className="flex h-4 w-4 items-center justify-center rounded"
                  style={{
                    border:     `1.5px solid ${errors.consent ? '#d8351e' : consent ? '#533afd' : '#b0bfcf'}`,
                    background: consent ? '#533afd' : 'white',
                    boxShadow:  errors.consent ? '0 0 0 3px rgba(216,53,30,.12)' : undefined,
                    transition: 'border-color .15s, background .15s',
                  }}
                >
                  {consent && (
                    <svg width="9" height="7" viewBox="0 0 9 7" fill="none" aria-hidden="true">
                      <path d="M1 3.5L3.5 6L8 1" stroke="white" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </div>
              </div>
              <span className="text-xs leading-relaxed" style={{ color: '#50617a' }}>
                Я согласен(а) на обработку предоставленных данных в соответствии с{' '}
                <Link
                  href="/legal/privacy"
                  className="underline underline-offset-2 hover:opacity-80"
                  style={{ color: '#533afd' }}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Политикой конфиденциальности
                </Link>.
                {' '}Данные используются только для ответа на ваш запрос.
              </span>
            </label>
            {errors.consent && <FieldError msg={errors.consent} />}
          </div>

          {/* ── Submit ───────────────────────────────────────────────────── */}
          <Button
            type="submit"
            disabled={loading}
            className="mt-1 w-full gap-2 font-medium"
            style={{
              background:   '#533afd',
              color:        'white',
              borderRadius: '10px',
              height:       '42px',
            }}
          >
            {loading && <Loader2 size={14} className="animate-spin" />}
            Отправить заявку
          </Button>

          {/* Fine print */}
          <p className="text-center text-xs leading-relaxed" style={{ color: '#95a4ba' }}>
            Без цен и обязательств. Нейтральная платформа — не торгуем продуктами участников.
          </p>
        </form>
      </div>
    </div>
  )
}

// ── Page shell ────────────────────────────────────────────────────────────────
export default function B2BRequestPage() {
  return (
    <>
      <title>Запросить доступ — PeptideTrust B2B</title>
      <div className="flex min-h-screen flex-col" style={{ background: '#f8fafd' }}>
        <Header />
        <main className="flex flex-1 justify-center px-4 py-14">
          <Suspense>
            <RequestForm />
          </Suspense>
        </main>
        <Footer />
      </div>
    </>
  )
}
