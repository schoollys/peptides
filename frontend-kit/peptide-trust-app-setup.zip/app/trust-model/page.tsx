import { StubLayout, StubCard } from '@/components/layout/stub-layout'

export default function TrustModelPage() {
  const factors = [
    { code: 'QEF',   label: 'Quality Evidence Factor',         desc: 'Документальные свидетельства качества продукции' },
    { code: 'PCF',   label: 'Protocol Compliance Factor',      desc: 'Соответствие цепочке протоколов чистоты' },
    { code: 'SCIF',  label: 'Supply Chain Integrity Factor',   desc: 'Целостность цепочки поставок' },
    { code: 'TRF',   label: 'Traceability Factor',             desc: 'Прослеживаемость от синтеза до доставки' },
    { code: 'FRF',   label: 'Fraud Risk Factor',               desc: 'Оценка риска мошенничества' },
    { code: 'CCF',   label: 'Complaint & Claim Factor',        desc: 'История жалоб и претензий' },
    { code: 'CVF',   label: 'Counterparty Verification Factor',desc: 'Верификация контрагентов' },
    { code: 'CVF_B', label: 'CVF Behavioral',                  desc: 'Поведенческие паттерны контрагента' },
    { code: 'RF',    label: 'Regulatory Factor',               desc: 'Соответствие нормативным требованиям' },
  ]

  return (
    <StubLayout>
      <title>Trust-модель — PeptideTrust</title>

      <StubCard>
        {/* Header */}
        <div className="mb-6 flex items-start gap-4">
          <div
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
            style={{ background: '#e8e9ff' }}
            aria-hidden="true"
          >
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M10 2L3 5v5c0 4.18 3.04 8.09 7 9 3.96-.91 7-4.82 7-9V5l-7-3z" stroke="#533afd" strokeWidth="1.5" strokeLinejoin="round"/>
            </svg>
          </div>
          <div>
            <h1 className="text-xl font-semibold tracking-heading" style={{ color: '#061b31' }}>
              Trust-модель PeptideTrust
            </h1>
            <p className="mt-1 text-sm leading-relaxed" style={{ color: '#64748d' }}>
              Методология расчёта Trust Score основана на 9 независимых факторах, взвешенных по роли участника и верифицированных через множитель V<sub>i</sub>. Score 0–100, доминирующий фактор всегда указан рядом со Score.
            </p>
          </div>
        </div>

        {/* Score formula — canonical */}
        <div
          className="mb-3 rounded-lg px-4 py-3 font-mono text-sm"
          style={{ background: '#f8fafd', border: '1px solid #e5edf5', color: '#3c4f69' }}
          aria-label="Формула Trust Score"
        >
          TS = Σ (F<sub>i</sub> · W<sub>i</sub> · D<sub>i</sub> · V<sub>i</sub>) · (1 − P<sub>s</sub>)
        </div>

        {/* Formula variable glossary */}
        <div className="mb-6 grid grid-cols-1 gap-2 sm:grid-cols-2">
          {[
            {
              token: 'Fᵢ',
              name: 'Factor score',
              desc: 'Нормированное значение i-го фактора [0–100].',
            },
            {
              token: 'Wᵢ',
              name: 'Weight',
              desc: 'Вес фактора для данной роли участника; Σ Wᵢ = 1.',
            },
            {
              token: 'Dᵢ',
              name: 'Decay (свежесть)',
              desc: 'Коэффициент затухания [0–1]: снижается по мере устаревания измерения. D = 1 при dᵢ ≤ 7 дней, линейно убывает до 0.5 при dᵢ = 90 дней.',
              highlight: true,
            },
            {
              token: 'Vᵢ',
              name: 'Verification multiplier',
              desc: 'Вес верификации [0–1]: насколько задокументировано и подтверждено значение фактора.',
            },
            {
              token: 'Pₛ',
              name: 'Penalty (штраф)',
              desc: 'Агрегированный штраф [0–1] за подтверждённые нарушения (upheld-инциденты). P = 0 при отсутствии инцидентов.',
              highlight: true,
            },
          ].map(({ token, name, desc, highlight }) => (
            <div
              key={token}
              className="rounded-lg px-3 py-2.5 flex gap-3 items-start"
              style={{
                background: highlight ? 'rgba(83,58,253,.05)' : '#f8fafd',
                border: `1px solid ${highlight ? 'rgba(83,58,253,.15)' : '#e5edf5'}`,
              }}
            >
              <span
                className="mt-0.5 shrink-0 rounded px-1.5 py-px font-mono text-[11px] font-bold"
                style={{ background: '#e8e9ff', color: '#533afd' }}
              >
                {token}
              </span>
              <div>
                <span className="text-xs font-semibold" style={{ color: '#061b31' }}>{name} </span>
                <span className="text-xs leading-relaxed" style={{ color: '#64748d' }}>{desc}</span>
              </div>
            </div>
          ))}
        </div>

        {/* 9 factors */}
        <div className="mb-6">
          <p className="mb-3 text-xs font-semibold uppercase tracking-wider" style={{ color: '#7d8ba4', letterSpacing: '0.05em' }}>
            9 факторов оценки
          </p>
          <ul className="flex flex-col divide-y divide-border">
            {factors.map(f => (
              <li key={f.code} className="flex items-start gap-3 py-2.5">
                <span
                  className="mt-0.5 shrink-0 rounded px-1.5 py-px font-mono text-[11px] font-semibold"
                  style={{ background: '#e8e9ff', color: '#533afd' }}
                >
                  {f.code}
                </span>
                <span>
                  <span className="text-sm font-medium" style={{ color: '#061b31' }}>{f.label}</span>
                  <span className="ml-2 text-sm" style={{ color: '#64748d' }}>{f.desc}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Vᵢ note */}
        <div
          className="mb-6 rounded-lg px-4 py-3 text-sm leading-relaxed"
          style={{ background: '#e8e9ff', border: '1px solid rgba(83,58,253,.18)', color: '#3a28c0' }}
        >
          Множитель верификации V<sub>i</sub> ∈ [0,1] снижает вес фактора при неполной или устаревшей документации. Сбалансированный Score отображается без доминирующего фактора.
        </div>

        {/* CTA */}
        <a
          href="/docs/methodology"
          className="inline-flex items-center gap-1 text-sm font-medium transition-colors hover:underline"
          style={{ color: '#533afd' }}
        >
          Подробная методология
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
            <path d="M5 3h6v6M11 3 3 11" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </a>
      </StubCard>
    </StubLayout>
  )
}
